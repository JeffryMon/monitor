using Dapper;
using Microsoft.Data.SqlClient;
using SQLServerManager.Api.Models;

namespace SQLServerManager.Api.Services;
public class CentralRepository {
 readonly string cs;
 public CentralRepository(IConfiguration c)=>cs=c.GetConnectionString("CentralDatabase")??throw new Exception("CentralDatabase no configurada.");
 SqlConnection C()=>new(cs);
 public async Task<IEnumerable<ServerDto>> Servers(){await using var c=C();return await c.QueryAsync<ServerDto>(@"SELECT SERVER_ID ServerId,NAME Name,HOST Host,PORT Port,INSTANCE_NAME InstanceName,ENVIRONMENT Environment,AUTH_TYPE AuthType,USERNAME Username,TRUST_SERVER_CERTIFICATE TrustServerCertificate,IS_ACTIVE IsActive,DESCRIPTION Description FROM dbo.SERVER ORDER BY NAME");}
 public async Task<ServerDto?> Server(int id){await using var c=C();return await c.QuerySingleOrDefaultAsync<ServerDto>("SELECT SERVER_ID ServerId,NAME Name,HOST Host,PORT Port,INSTANCE_NAME InstanceName,ENVIRONMENT Environment,AUTH_TYPE AuthType,USERNAME Username,TRUST_SERVER_CERTIFICATE TrustServerCertificate,IS_ACTIVE IsActive,DESCRIPTION Description FROM dbo.SERVER WHERE SERVER_ID=@id",new{id});}
 public async Task<int> AddServer(CreateServerRequest x){await using var c=C();return await c.ExecuteScalarAsync<int>(@"INSERT dbo.SERVER(NAME,HOST,PORT,INSTANCE_NAME,ENVIRONMENT,AUTH_TYPE,USERNAME,TRUST_SERVER_CERTIFICATE,DESCRIPTION) VALUES(@Name,@Host,@Port,@InstanceName,@Environment,@AuthType,@Username,@TrustServerCertificate,@Description);SELECT CONVERT(int,SCOPE_IDENTITY());",x);}
 public async Task SaveMetric(int id,DashboardDto x){await using var c=C();await c.ExecuteAsync(@"INSERT dbo.SERVER_METRIC(SERVER_ID,CPU_PERCENT,TOTAL_MEMORY_MB,SQL_MEMORY_MB,CONNECTIONS,DATABASE_COUNT) VALUES(@id,@CpuPercent,@TotalMemoryMb,@SqlMemoryMb,@Connections,@DatabaseCount)",new{id,x.CpuPercent,x.TotalMemoryMb,x.SqlMemoryMb,x.Connections,x.DatabaseCount});}
 public async Task<IEnumerable<MetricDto>> Metrics(int id,int hours){await using var c=C();return await c.QueryAsync<MetricDto>(@"SELECT CONVERT(varchar(19),COLLECTED_AT,120) CollectedAt,CPU_PERCENT CpuPercent,TOTAL_MEMORY_MB TotalMemoryMb,SQL_MEMORY_MB SqlMemoryMb,CONNECTIONS Connections,DATABASE_COUNT DatabaseCount FROM dbo.SERVER_METRIC WHERE SERVER_ID=@id AND COLLECTED_AT>=DATEADD(hour,-@hours,SYSDATETIME()) ORDER BY COLLECTED_AT",new{id,hours});}
 public async Task<IEnumerable<AlertRuleDto>> Alerts(){await using var c=C();return await c.QueryAsync<AlertRuleDto>("SELECT ALERT_RULE_ID AlertRuleId,NAME Name,SERVER_ID ServerId,METRIC_CODE MetricCode,OPERATOR Operator,THRESHOLD Threshold,IS_ACTIVE IsActive FROM dbo.ALERT_RULE ORDER BY NAME");}
 public async Task<int> AddAlert(CreateAlertRuleRequest x){await using var c=C();return await c.ExecuteScalarAsync<int>(@"INSERT dbo.ALERT_RULE(NAME,SERVER_ID,METRIC_CODE,OPERATOR,THRESHOLD) VALUES(@Name,@ServerId,@MetricCode,@Operator,@Threshold);SELECT CONVERT(int,SCOPE_IDENTITY())",x);}
 public async Task<IEnumerable<dynamic>> Audit(int take){await using var c=C();return await c.QueryAsync(@"SELECT TOP(@take) LOG_ID LogId,SERVER_ID ServerId,ACTION Action,OBJECT_NAME ObjectName,RESULT Result,ERROR_MESSAGE ErrorMessage,CREATED_AT CreatedAt FROM dbo.AUDIT_LOG ORDER BY CREATED_AT DESC",new{take});}
 public async Task Log(int id,string action,string obj,string result,string? error=null){await using var c=C();await c.ExecuteAsync(@"INSERT dbo.AUDIT_LOG(SERVER_ID,ACTION,OBJECT_TYPE,OBJECT_NAME,RESULT,ERROR_MESSAGE) VALUES(@id,@action,'SQL',@obj,@result,@error)",new{id,action,obj,result,error});}
}
