using Dapper;
using Microsoft.Data.SqlClient;
using SQLServerManager.Api.Models;

namespace SQLServerManager.Api.Services;
public class SqlServerService {
 async Task<SqlConnection> C(ServerDto s,string? pw){
  var b=new SqlConnectionStringBuilder{DataSource=string.IsNullOrWhiteSpace(s.InstanceName)?$"{s.Host},{s.Port}":$"{s.Host}\\{s.InstanceName}",InitialCatalog="master",ConnectTimeout=5,Encrypt=true,TrustServerCertificate=s.TrustServerCertificate};
  if(s.AuthType.Equals("Windows",StringComparison.OrdinalIgnoreCase)) b.IntegratedSecurity=true; else {b.UserID=s.Username??"";b.Password=pw??"";}
  var c=new SqlConnection(b.ConnectionString);await c.OpenAsync();return c;
 }
 public async Task<ConnectionStatusDto> Test(ServerDto s,string? pw){try{await using var c=await C(s,pw);var x=await c.QuerySingleAsync("SELECT CAST(SERVERPROPERTY('ServerName') AS nvarchar(256)) ServerName,CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(100)) ProductVersion,CAST(SERVERPROPERTY('Edition') AS nvarchar(200)) Edition");return new(){Connected=true,ServerName=x.ServerName,ProductVersion=x.ProductVersion,Edition=x.Edition};}catch(Exception e){return new(){Error=e.Message};}}
 public async Task<DashboardDto> Dashboard(ServerDto s,string? pw){await using var c=await C(s,pw);var st=await c.QuerySingleAsync<ConnectionStatusDto>("SELECT CAST(SERVERPROPERTY('ServerName') AS nvarchar(256)) ServerName,CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(100)) ProductVersion,CAST(SERVERPROPERTY('Edition') AS nvarchar(200)) Edition");var m=await c.QuerySingleAsync<dynamic>("SELECT physical_memory_kb/1024 TotalMemoryMb,committed_kb/1024 SqlMemoryMb FROM sys.dm_os_sys_info");var n=await c.ExecuteScalarAsync<int>("SELECT COUNT(*) FROM sys.dm_exec_sessions WHERE is_user_process=1");var d=await c.ExecuteScalarAsync<int>("SELECT COUNT(*) FROM sys.databases WHERE database_id>4");return new(){Status=st,TotalMemoryMb=m.TotalMemoryMb,SqlMemoryMb=m.SqlMemoryMb,Connections=n,DatabaseCount=d};}
 public async Task<IEnumerable<LoginDto>> Logins(ServerDto s,string pw){await using var c=await C(s,pw);return await c.QueryAsync<LoginDto>("SELECT name Name,type_desc TypeDescription,is_disabled IsDisabled,default_database_name DefaultDatabase,CONVERT(varchar(19),create_date,120) CreateDate FROM sys.server_principals WHERE type IN('S','U','G') ORDER BY name");}
 public async Task<IEnumerable<RoleDto>> Roles(ServerDto s,string pw){await using var c=await C(s,pw);return await c.QueryAsync<RoleDto>("SELECT name Name,type_desc TypeDescription FROM sys.server_principals WHERE type='R' ORDER BY name");}
 public async Task<IEnumerable<DatabaseDto>> Databases(ServerDto s,string pw){await using var c=await C(s,pw);return await c.QueryAsync<DatabaseDto>("SELECT d.name Name,d.state_desc StateDescription,d.recovery_model_desc RecoveryModel,CAST(SUM(m.size)*8.0/1024 AS decimal(18,2)) SizeMb,CAST(SUM(CASE WHEN m.type=0 THEN FILEPROPERTY(m.name,'SpaceUsed') ELSE 0 END)*8.0/1024 AS decimal(18,2)) UsedMb FROM sys.databases d LEFT JOIN sys.master_files m ON m.database_id=d.database_id GROUP BY d.name,d.state_desc,d.recovery_model_desc ORDER BY d.name");}
 public async Task<IEnumerable<SessionDto>> Sessions(ServerDto s,string pw){await using var c=await C(s,pw);return await c.QueryAsync<SessionDto>("SELECT s.session_id SessionId,s.login_name LoginName,DB_NAME(s.database_id) DatabaseName,s.status Status,s.cpu_time CpuMs,s.reads Reads,s.writes Writes,r.blocking_session_id BlockingSessionId FROM sys.dm_exec_sessions s LEFT JOIN sys.dm_exec_requests r ON r.session_id=s.session_id WHERE s.is_user_process=1 ORDER BY s.cpu_time DESC");}
 public async Task Kill(ServerDto s,string pw,int spid){await using var c=await C(s,pw);await c.ExecuteAsync($"KILL {spid}");}
}
