# SQL Server Manager V2
Consola centralizada para administrar y monitorizar múltiples SQL Server.

## Incluye
- Dashboard
- Inventario de servidores
- Prueba de conexión
- Logins: listar, crear, habilitar/deshabilitar y eliminar
- Server Roles
- Bases de datos
- Sesiones y KILL
- SQL Server Agent
- Backups
- Archivos MDF/NDF/LDF
- Histórico de métricas
- Gráfica CPU/conexiones
- Reglas de alertas
- Auditoría
- Roles/permisos de aplicación preparados

## Instalación
1. Ejecutar `database/01_create_database.sql`.
2. Abrir `SQLServerManager.sln`.
3. Configurar `appsettings.json`.
4. Ejecutar con Visual Studio 2022.
5. Abrir Swagger o la pantalla principal.

Requiere .NET 8 y SQL Server.
