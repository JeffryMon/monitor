# WorkPulse v0.1 — starter de desarrollo

Starter para Windows + .NET 8 + ASP.NET Core + SQL Server + IIS.

## Incluye
- `src/WorkPulse.Api`: API de ingesta con clave por agente, EF Core y endpoints de salud/eventos.
- `src/WorkPulse.Agent`: agente de consola para Windows que registra aplicación en primer plano, duración aproximada e inactividad y envía eventos a la API.
- `database/001_schema.sql`: esquema inicial SQL Server.
- `dashboard/index.html`: dashboard mínimo que consulta la API.
- Configuración explícita para mantener desactivadas las funciones de dominios web y capturas de pantalla hasta definir política, consentimiento y controles de acceso.

## Requisitos
- .NET 8 SDK
- SQL Server (Developer/Express para desarrollo)
- Windows 10/11 para ejecutar el agente
- IIS + ASP.NET Core Hosting Bundle para despliegue de la API

## 1. Crear la base de datos
Ejecuta `database/001_schema.sql` en SQL Server Management Studio. Crea la base `WorkPulse`.

## 2. Configurar la API
Edita `src/WorkPulse.Api/appsettings.json` y cambia:
- `ConnectionStrings:WorkPulse`
- `AgentAuth:ApiKey` por un secreto largo y único.

No uses la clave de ejemplo en producción. En producción, usa variables de entorno o un gestor de secretos.

Desde `src/WorkPulse.Api`:
```powershell
dotnet restore
dotnet run
```
La API escucha en la URL que indique la consola (normalmente `http://localhost:5xxx`).

## 3. Configurar y ejecutar el agente
Edita `src/WorkPulse.Agent/appsettings.json`:
- `ApiBaseUrl`: URL base de la API, sin `/` final.
- `ApiKey`: debe coincidir con la clave configurada en la API.
- `DeviceId`: identificador estable del equipo, por ejemplo `PC-001`.
- `PollIntervalSeconds`: intervalo de muestreo.

Desde `src/WorkPulse.Agent`:
```powershell
dotnet restore
dotnet run
```
El agente muestra una indicación visible en consola mientras está activo. Para detenerlo, presiona Ctrl+C.

## 4. Dashboard
Abre `dashboard/index.html` en un navegador y configura la URL de la API en la constante `API_BASE`. Para evitar problemas CORS, es preferible servir el dashboard desde la misma aplicación web o configurar CORS con un origen concreto antes de desplegarlo.

## Endpoints
- `GET /health` — estado básico.
- `POST /api/events` — ingesta autenticada.
- `GET /api/events/recent?take=100` — eventos recientes (requiere clave de agente en este starter).

La clave compartida es un punto de partida para desarrollo, no una solución completa de identidad empresarial. En producción conviene usar identidad individual por dispositivo, rotación de credenciales, HTTPS obligatorio, límites de frecuencia, retención y auditoría.

## Privacidad y alcance
- La captura de títulos de ventana puede incluir información personal. Revisa la política de la organización y minimiza el contenido almacenado.
- No captura teclas, contraseñas, contenido de formularios ni audio.
- No incluye capturas de pantalla automáticas ni rastreo del navegador. Estos módulos deben diseñarse como funciones opcionales, visibles y expresamente autorizadas, con controles de acceso, retención y exclusión de ventanas sensibles.
- No instales el agente en equipos ajenos ni recopiles actividad sin autorización adecuada.
- Para uso real, informa a las personas sobre qué se registra, por qué, cuándo, durante cuánto tiempo y quién puede verlo.

## Siguientes pasos sugeridos
1. Sustituir la clave compartida por credenciales por dispositivo.
2. Añadir usuarios, equipos, grupos y políticas de retención.
3. Añadir servicio de Windows con instalación/desinstalación documentada y un indicador visible de estado.
4. Añadir una extensión de navegador administrada para dominios permitidos, con consentimiento y lista de exclusión.
5. Diseñar un flujo de captura de pantalla opcional con aviso visible y acceso restringido; no habilitarlo por defecto.
6. Publicar API/dashboard en IIS con HTTPS y CORS de origen limitado.
