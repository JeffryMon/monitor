using System.Diagnostics;
using System.Net.Http.Json;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;

if (!OperatingSystem.IsWindows())
{
    Console.Error.WriteLine("WorkPulse.Agent requiere Windows.");
    return;
}

var configPath = Path.Combine(AppContext.BaseDirectory, "appsettings.json");
if (!File.Exists(configPath))
{
    Console.Error.WriteLine($"No se encontró configuración: {configPath}");
    return;
}
using var configDoc = JsonDocument.Parse(await File.ReadAllTextAsync(configPath));
var root = configDoc.RootElement;
string apiBaseUrl = root.GetProperty("ApiBaseUrl").GetString() ?? "";
string apiKey = root.GetProperty("ApiKey").GetString() ?? "";
string deviceId = root.GetProperty("DeviceId").GetString() ?? Environment.MachineName;
int pollSeconds = Math.Clamp(root.GetProperty("PollIntervalSeconds").GetInt32(), 10, 300);
int idleThreshold = Math.Clamp(root.GetProperty("IdleThresholdSeconds").GetInt32(), 60, 3600);
bool captureTitles = root.GetProperty("CaptureWindowTitles").GetBoolean();

if (apiKey.Length < 24 || apiKey == "REPLACE_WITH_A_LONG_RANDOM_SECRET")
{
    Console.Error.WriteLine("Configura una clave API larga y única en appsettings.json.");
    return;
}

using var client = new HttpClient { BaseAddress = new Uri(apiBaseUrl.TrimEnd('/') + "/") };
client.DefaultRequestHeaders.Add("X-WorkPulse-Key", apiKey);
using var stop = new CancellationTokenSource();
Console.CancelKeyPress += (_, e) => { e.Cancel = true; stop.Cancel(); };

Console.WriteLine("WorkPulse Agent activo. La recopilación está visible en esta consola.");
Console.WriteLine($"Equipo: {deviceId}. Intervalo: {pollSeconds}s. Ctrl+C para detener.");
Console.WriteLine("Títulos de ventana: " + (captureTitles ? "habilitados" : "deshabilitados"));
Console.WriteLine("Dominios web y capturas de pantalla: deshabilitados en esta versión.");

string? previousApp = null;
DateTime previousAt = DateTime.UtcNow;
try
{
    while (!stop.IsCancellationRequested)
    {
        var now = DateTime.UtcNow;
        var idleSeconds = WindowsActivity.GetIdleSeconds();
        var appName = WindowsActivity.GetForegroundProcessName();
        var title = captureTitles ? WindowsActivity.GetForegroundWindowTitle() : null;
        var isIdle = idleSeconds >= idleThreshold;

        var payload = new ActivityPayload
        {
            EventGuid = Guid.NewGuid(),
            DeviceId = deviceId,
            UserName = Environment.UserName,
            EventType = isIdle ? "idle" : "application_activity",
            ApplicationName = isIdle ? null : appName,
            WindowTitle = isIdle ? null : title,
            IsIdle = isIdle,
            DurationSeconds = Math.Clamp((int)(now - previousAt).TotalSeconds, 0, pollSeconds * 3),
            OccurredAtUtc = now
        };

        // Envía un evento por intervalo. El servidor valida y persiste la carga.
        try
        {
            var response = await client.PostAsJsonAsync("api/events", payload, stop.Token);
            if (!response.IsSuccessStatusCode)
                Console.WriteLine($"{now:O} API respondió {(int)response.StatusCode} ({response.StatusCode}).");
            else
                Console.WriteLine($"{now:HH:mm:ss} {(isIdle ? "Inactivo" : appName ?? "Aplicación desconocida")} — evento enviado.");
        }
        catch (OperationCanceledException) when (stop.IsCancellationRequested) { break; }
        catch (Exception ex) { Console.WriteLine($"No se pudo enviar el evento: {ex.Message}"); }

        previousApp = appName;
        previousAt = now;
        await Task.Delay(TimeSpan.FromSeconds(pollSeconds), stop.Token);
    }
}
catch (OperationCanceledException) { }
Console.WriteLine("WorkPulse Agent detenido.");

public sealed class ActivityPayload
{
    public Guid EventGuid { get; set; }
    public string DeviceId { get; set; } = "";
    public string? UserName { get; set; }
    public string EventType { get; set; } = "";
    public string? ApplicationName { get; set; }
    public string? WindowTitle { get; set; }
    public bool IsIdle { get; set; }
    public int DurationSeconds { get; set; }
    public DateTime OccurredAtUtc { get; set; }
}

internal static class WindowsActivity
{
    [StructLayout(LayoutKind.Sequential)]
    private struct LASTINPUTINFO
    {
        public uint cbSize;
        public uint dwTime;
    }

    [DllImport("user32.dll")]
    private static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);
    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);
    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);

    public static int GetIdleSeconds()
    {
        var info = new LASTINPUTINFO { cbSize = (uint)Marshal.SizeOf<LASTINPUTINFO>() };
        if (!GetLastInputInfo(ref info)) return 0;
        uint elapsed = unchecked((uint)Environment.TickCount - info.dwTime);
        return (int)(elapsed / 1000);
    }

    public static string? GetForegroundProcessName()
    {
        var hwnd = GetForegroundWindow();
        if (hwnd == IntPtr.Zero) return null;
        GetWindowThreadProcessId(hwnd, out var pid);
        try { return Process.GetProcessById((int)pid).ProcessName; }
        catch { return null; }
    }

    public static string? GetForegroundWindowTitle()
    {
        var hwnd = GetForegroundWindow();
        if (hwnd == IntPtr.Zero) return null;
        var buffer = new StringBuilder(1024);
        _ = GetWindowText(hwnd, buffer, buffer.Capacity);
        var value = buffer.ToString();
        return string.IsNullOrWhiteSpace(value) ? null : value[..Math.Min(value.Length, 500)];
    }
}
