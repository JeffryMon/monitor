using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using WorkPulse.Api.Data;
using WorkPulse.Api.Models;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<WorkPulseDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("WorkPulse")));
builder.Services.AddCors(options =>
{
    options.AddPolicy("Dashboard", policy =>
        policy.WithOrigins(builder.Configuration.GetSection("Dashboard:AllowedOrigin").Value ?? "http://localhost:5500")
              .AllowAnyHeader()
              .AllowAnyMethod());
});

var app = builder.Build();
app.UseCors("Dashboard");

bool IsAuthorized(HttpRequest request)
{
    var expected = builder.Configuration["AgentAuth:ApiKey"] ?? "";
    var supplied = request.Headers["X-WorkPulse-Key"].ToString();
    if (expected.Length < 24 || expected == "REPLACE_WITH_A_LONG_RANDOM_SECRET" || supplied.Length == 0)
        return false;
    return CryptographicOperations.FixedTimeEquals(
        Encoding.UTF8.GetBytes(expected), Encoding.UTF8.GetBytes(supplied));
}

app.MapGet("/health", () => Results.Ok(new { status = "ok", service = "WorkPulse.Api" }));

app.MapPost("/api/events", async (HttpRequest request, ActivityEventInput input, WorkPulseDbContext db) =>
{
    if (!IsAuthorized(request)) return Results.Unauthorized();
    if (string.IsNullOrWhiteSpace(input.DeviceId) || input.DeviceId.Length > 100)
        return Results.BadRequest(new { error = "DeviceId es obligatorio y máximo 100 caracteres." });
    if (string.IsNullOrWhiteSpace(input.EventType) || input.EventType.Length > 40)
        return Results.BadRequest(new { error = "EventType es obligatorio y máximo 40 caracteres." });
    if (input.DurationSeconds < 0 || input.DurationSeconds > 86400)
        return Results.BadRequest(new { error = "DurationSeconds fuera de rango." });

    var device = await db.Devices.FindAsync(input.DeviceId);
    if (device is null)
    {
        device = new Device { DeviceId = input.DeviceId, OperatingSystem = "Windows", FirstSeenUtc = DateTime.UtcNow };
        db.Devices.Add(device);
    }
    if (!device.IsEnabled) return Results.StatusCode(StatusCodes.Status403Forbidden);
    device.LastSeenUtc = DateTime.UtcNow;

    var item = new ActivityEvent
    {
        EventGuid = input.EventGuid == Guid.Empty ? Guid.NewGuid() : input.EventGuid,
        DeviceId = input.DeviceId,
        UserName = input.UserName,
        EventType = input.EventType,
        ApplicationName = input.ApplicationName,
        WindowTitle = input.WindowTitle,
        Domain = null, // Website collection is intentionally disabled in this starter.
        IsIdle = input.IsIdle,
        DurationSeconds = input.DurationSeconds,
        OccurredAtUtc = input.OccurredAtUtc == default ? DateTime.UtcNow : input.OccurredAtUtc.ToUniversalTime(),
        ReceivedAtUtc = DateTime.UtcNow
    };
    db.ActivityEvents.Add(item);
    await db.SaveChangesAsync();
    return Results.Accepted($"/api/events/{item.EventId}", new { item.EventId, item.EventGuid });
});

app.MapGet("/api/events/recent", async (HttpRequest request, int? take, WorkPulseDbContext db) =>
{
    if (!IsAuthorized(request)) return Results.Unauthorized();
    var count = Math.Clamp(take ?? 50, 1, 200);
    var rows = await db.ActivityEvents.AsNoTracking()
        .OrderByDescending(e => e.OccurredAtUtc)
        .Take(count)
        .Select(e => new {
            e.EventId, e.DeviceId, e.UserName, e.EventType, e.ApplicationName,
            e.WindowTitle, e.IsIdle, e.DurationSeconds, e.OccurredAtUtc, e.ReceivedAtUtc
        }).ToListAsync();
    return Results.Ok(rows);
});

app.Run();
