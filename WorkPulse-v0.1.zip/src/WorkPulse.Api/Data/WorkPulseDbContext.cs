using Microsoft.EntityFrameworkCore;
using WorkPulse.Api.Models;

namespace WorkPulse.Api.Data;

public sealed class WorkPulseDbContext(DbContextOptions<WorkPulseDbContext> options) : DbContext(options)
{
    public DbSet<Device> Devices => Set<Device>();
    public DbSet<ActivityEvent> ActivityEvents => Set<ActivityEvent>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Device>(e =>
        {
            e.ToTable("Devices");
            e.HasKey(x => x.DeviceId);
            e.Property(x => x.DeviceId).HasMaxLength(100);
            e.Property(x => x.OperatingSystem).HasMaxLength(100).IsRequired();
            e.Property(x => x.DisplayName).HasMaxLength(200);
            e.Property(x => x.AgentVersion).HasMaxLength(40);
        });
        modelBuilder.Entity<ActivityEvent>(e =>
        {
            e.ToTable("ActivityEvents");
            e.HasKey(x => x.EventId);
            e.HasIndex(x => x.EventGuid).IsUnique();
            e.HasIndex(x => new { x.DeviceId, x.OccurredAtUtc });
            e.Property(x => x.DeviceId).HasMaxLength(100).IsRequired();
            e.Property(x => x.UserName).HasMaxLength(256);
            e.Property(x => x.EventType).HasMaxLength(40).IsRequired();
            e.Property(x => x.ApplicationName).HasMaxLength(260);
            e.Property(x => x.WindowTitle).HasMaxLength(500);
            e.Property(x => x.Domain).HasMaxLength(253);
            e.HasOne(x => x.Device).WithMany(x => x.ActivityEvents).HasForeignKey(x => x.DeviceId);
        });
    }
}
