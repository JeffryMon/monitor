namespace WorkPulse.Api.Models;

public sealed class Device
{
    public string DeviceId { get; set; } = "";
    public string? DisplayName { get; set; }
    public string OperatingSystem { get; set; } = "Windows";
    public string? AgentVersion { get; set; }
    public DateTime FirstSeenUtc { get; set; }
    public DateTime? LastSeenUtc { get; set; }
    public bool IsEnabled { get; set; } = true;
    public List<ActivityEvent> ActivityEvents { get; set; } = [];
}
