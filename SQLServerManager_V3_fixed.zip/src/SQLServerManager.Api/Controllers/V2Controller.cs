using Microsoft.AspNetCore.Mvc;
using SQLServerManager.Api.Models;
using SQLServerManager.Api.Services;

namespace SQLServerManager.Api.Controllers;
[ApiController][Route("api/v2")]
public class V2Controller:ControllerBase{
 readonly CentralRepository r;readonly SqlServerService s;
 public V2Controller(CentralRepository r,SqlServerService s){this.r=r;this.s=s;}
 [HttpPost("servers/{id:int}/metrics/collect")] public async Task<IActionResult> Collect(int id,ConnectionRequest x){var v=await r.Server(id);if(v is null)return NotFound();try{var m=await s.Dashboard(v);await r.SaveMetric(id,m);return Ok(m);}catch(Exception e){return BadRequest(new{error=e.Message});}}
 [HttpGet("servers/{id:int}/metrics")] public async Task<IActionResult> Metrics(int id,[FromQuery]int hours=24)=>Ok(await r.Metrics(id,Math.Clamp(hours,1,720)));
 [HttpGet("audit")] public async Task<IActionResult> Audit([FromQuery]int take=300)=>Ok(await r.Audit(Math.Clamp(take,1,1000)));
 [HttpGet("alerts")] public async Task<IActionResult> Alerts()=>Ok(await r.Alerts());
 [HttpPost("alerts")] public async Task<IActionResult> Alert(CreateAlertRuleRequest x)=>Ok(new{id=await r.AddAlert(x)});
}
