using Microsoft.AspNetCore.Mvc; using SQLServerManager.Api.Models; using SQLServerManager.Api.Services;
namespace SQLServerManager.Api.Controllers;
[ApiController][Route("api/servers")]
public class ServersController:ControllerBase{
 readonly CentralRepository r;readonly SqlServerService s;readonly AuditService a;
 public ServersController(CentralRepository r,SqlServerService s,AuditService a){this.r=r;this.s=s;this.a=a;}
 [HttpGet] public async Task<IActionResult> List()=>Ok(await r.Servers());
 [HttpPost] public async Task<IActionResult> Add(CreateServerRequest x)=>Ok(new{id=await r.AddServer(x)});
 [HttpPut("{id:int}")] public async Task<IActionResult> Update(int id,CreateServerRequest x){if(await r.Server(id) is null)return NotFound();await r.UpdateServer(id,x);return Ok();}
 [HttpPost("{id:int}/active")] public async Task<IActionResult> Active(int id,[FromBody]bool active){if(await r.Server(id) is null)return NotFound();await r.SetActive(id,active);return Ok();}
 [HttpPost("{id:int}/test")] public async Task<IActionResult> Test(int id,ConnectionRequest x){var v=await r.Server(id);return v is null?NotFound():Ok(await s.Test(v));}
 [HttpPost("{id:int}/dashboard")] public async Task<IActionResult> Dashboard(int id,ConnectionRequest x){var v=await r.Server(id);if(v is null)return NotFound();try{return Ok(await s.Dashboard(v));}catch(Exception e){return BadRequest(new{error=e.Message});}}
 [HttpPost("{id:int}/logins")] public async Task<IActionResult> Logins(int id){var v=await r.Server(id);if(v is null)return NotFound();return Ok(await s.Logins(v));}
 [HttpPost("{id:int}/roles")] public async Task<IActionResult> Roles(int id){var v=await r.Server(id);if(v is null)return NotFound();return Ok(await s.Roles(v));}
 [HttpPost("{id:int}/databases")] public async Task<IActionResult> Databases(int id){var v=await r.Server(id);if(v is null)return NotFound();return Ok(await s.Databases(v));}
 [HttpPost("{id:int}/sessions")] public async Task<IActionResult> Sessions(int id){var v=await r.Server(id);if(v is null)return NotFound();return Ok(await s.Sessions(v));}
 [HttpPost("{id:int}/sessions/{spid:int}/kill")] public async Task<IActionResult> Kill(int id,int spid){var v=await r.Server(id);if(v is null)return NotFound();try{await s.Kill(v,spid);await a.Ok(id,"KILL_SESSION",spid.ToString());return Ok();}catch(Exception e){await a.Error(id,"KILL_SESSION",spid.ToString(),e);return BadRequest(new{error=e.Message});}}
}
