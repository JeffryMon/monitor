using Microsoft.OpenApi.Models;
using SQLServerManager.Api.Services;

var b=WebApplication.CreateBuilder(args);
b.Services.AddControllers();
b.Services.AddEndpointsApiExplorer();
b.Services.AddSwaggerGen(c=>c.SwaggerDoc("v1",new OpenApiInfo{Title="SQL Server Manager API",Version="2.0"}));
b.Services.AddSingleton<CentralRepository>();
b.Services.AddSingleton<SqlServerService>();
b.Services.AddSingleton<AuditService>();
var app=b.Build();
app.UseDefaultFiles();
app.UseStaticFiles();
app.UseSwagger();
app.UseSwaggerUI();
app.MapControllers();
app.Run();
