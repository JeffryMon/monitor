namespace SQLServerManager.Api.Services;
public class AuditService {
 readonly CentralRepository r; public AuditService(CentralRepository r)=>this.r=r;
 public Task Ok(int id,string a,string o)=>r.Log(id,a,o,"SUCCESS");
 public Task Error(int id,string a,string o,Exception e)=>r.Log(id,a,o,"ERROR",e.Message);
}
