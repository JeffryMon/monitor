# SQL Server Manager V3

Consola centralizada para administrar y monitorizar múltiples SQL Server.

## Cambios V3
- Conexiones a SQL Server exclusivamente con **Windows Authentication** mediante `IntegratedSecurity=true`.
- No se almacenan contraseñas SQL en la base central.
- Todos los formularios de ingreso de datos relevantes usan **popups/modales**.
- Campos de claves/datos secretos usan `type=password`, no se muestran en claro y no se persisten en la UI.
- Menú lateral con iconos Bootstrap Icons.
- Alta y edición de servidores desde modal.
- Inventario ampliado: ambiente (PROD/QA/DEV/UAT/DR/TEST), versión SQL, edición, sistema operativo, ubicación, responsable, tags y descripción.
- Activar/desactivar servidor desde el inventario.
- Prueba de conexión con un clic.

## Requisito importante de Windows Authentication
La aplicación usa la identidad del proceso ASP.NET Core/IIS para autenticarse contra cada SQL Server. Si se ejecuta como Windows Service/IIS, esa cuenta de servicio debe tener permisos en cada instancia SQL Server.

Para IIS normalmente se recomienda un Application Pool con una cuenta de dominio dedicada y permisos mínimos necesarios en SQL Server.

## Instalación
1. Ejecutar `database/01_create_database.sql` en la instancia central.
2. Revisar `appsettings.json` y dejar la conexión a `SQL_ADMIN_CENTER` usando Windows Authentication.
3. Compilar con .NET 8.
4. Ejecutar el API y abrir Swagger o `/`.

> V3 todavía no implementa autenticación de usuarios de la propia aplicación. La siguiente fase recomendada es integrar Windows/AD o ASP.NET Identity y permisos por acción (MONITOR, DBA, SUPERADMIN).
