# WorkPulse V6 — Portal + agente de bandeja (prototipo integral)

## Qué incluye
- `Portal/index.html`: portal de demostración con dashboard, empleados, equipos/dispositivos, actividad, ajustes y exportación/importación JSON.
- `Agent/WorkPulse.Agent.csproj` y código C#: agente Windows con icono en bandeja, estado visible, nombre del equipo, usuario de sesión de Windows, IP, sistema operativo y registro local de latidos.
- El agente se configura para iniciar con Windows por defecto; el menú de bandeja permite desactivarlo.
- `Database/WorkPulse.sql`: esquema inicial de SQL Server para usuarios, estructura organizacional, dispositivos, latidos, actividad, solicitudes y auditoría.
- `build.ps1`: compila el agente en una máquina Windows que tenga Visual Studio Build Tools/MSBuild y .NET Framework 4.7.2 Developer Pack.

## Importante: límites de esta entrega
Esta es una versión de prueba funcional visual/local. El portal guarda sus datos de demostración en `localStorage` del navegador y permite exportar/importar JSON. **Todavía no está conectado a SQL Server ni al agente por una API**, por lo que el dashboard no mostrará automáticamente los latidos del agente. El SQL es el esquema base, no una base de datos ya desplegada.
No se adjunta un `.exe` precompilado: este entorno no tiene el compilador de Windows/.NET Framework. El código fuente y el script de compilación están incluidos; compílalo en Windows.

## Abrir el portal
1. Extrae el ZIP.
2. Abre `Portal/index.html` con Edge o Chrome.
3. Es una demo local; los datos quedan guardados en ese navegador y perfil.

## Compilar el agente en Windows
1. Instala Visual Studio 2022 o Build Tools con desarrollo de escritorio de .NET y el **.NET Framework 4.7.2 Developer Pack**.
2. Abre PowerShell en la carpeta raíz extraída.
3. Ejecuta:
   ```powershell
   Set-ExecutionPolicy -Scope Process Bypass
   .\build.ps1
   ```
4. El ejecutable quedará en `Agent\bin\Release\WorkPulse.Agent.exe`.
5. Ejecútalo. Al primer inicio intenta crear el acceso directo en la carpeta Inicio del usuario actual.
6. Para comprobar el icono: Configuración de Windows → Personalización → Barra de tareas → Otros iconos de la bandeja del sistema (el nombre puede variar) → habilita WorkPulse.

## Inicio automático
El agente registra un acceso directo en la carpeta `shell:startup` del usuario que lo ejecuta. Esto inicia la aplicación cuando ese usuario inicia sesión; **no es un servicio de Windows y no arranca antes del inicio de sesión**. Para todos los usuarios o despliegue corporativo se debe instalar/configurar por separado con permisos de administrador.

## Siguiente paso para una versión conectada
- Publicar API HTTPS con autenticación y autorización por rol.
- Guardar usuarios, contraseñas con hash, dispositivos y actividad en SQL Server.
- Vincular equipos a empleados mediante código de emparejamiento (sin Active Directory).
- Configurar retención, aviso/consentimiento y política de privacidad antes de monitoreo real.
