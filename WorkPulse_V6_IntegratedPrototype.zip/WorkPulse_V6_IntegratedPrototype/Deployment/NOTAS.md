# Notas de despliegue

- Portal demo: abre `Portal/index.html`. Para hosting, copia la carpeta a IIS como sitio/directorio virtual estático.
- El agente es una aplicación de bandeja por usuario, no un servicio. El inicio automático es por usuario de Windows.
- SQL Server: ejecuta `Database/WorkPulse.sql` en un ambiente de prueba.
- No conectes esta maqueta a datos reales hasta implementar API, autenticación de servidor, permisos por rol, TLS, consentimiento y retención de datos.
- El icono usa `SystemIcons.Application` como placeholder. En una versión de distribución se recomienda añadir un icono `.ico` propio y firmar el ejecutable.
