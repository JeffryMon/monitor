using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;

namespace WorkPulse.Agent
{
    internal sealed class MainForm : Form
    {
        private readonly string _logPath;
        private readonly Label _status = new Label();
        private readonly TextBox _log = new TextBox();

        public MainForm(string logPath)
        {
            _logPath = logPath;
            Text = "WorkPulse — agente de escritorio";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(660, 470);
            MinimumSize = new Size(600, 400);
            Font = new Font("Segoe UI", 9F);
            var title = new Label { Text = "WorkPulse", Font = new Font("Segoe UI", 18F, FontStyle.Bold), AutoSize = true, Location = new Point(20, 18) };
            _status.SetBounds(22, 58, 600, 22);
            _log.Multiline = true;
            _log.ReadOnly = true;
            _log.ScrollBars = ScrollBars.Vertical;
            _log.SetBounds(22, 95, 600, 290);
            var refresh = new Button { Text = "Actualizar", Location = new Point(22, 395), Size = new Size(110, 30) };
            refresh.Click += (s, e) => RefreshStatus();
            Controls.AddRange(new Control[] { title, _status, _log, refresh });
            RefreshStatus();
        }

        public void RefreshStatus()
        {
            string ip = "No disponible";
            try
            {
                var host = Dns.GetHostEntry(Dns.GetHostName());
                ip = host.AddressList.FirstOrDefault(a => a.AddressFamily == AddressFamily.InterNetwork && !IPAddress.IsLoopback(a))?.ToString() ?? ip;
            }
            catch { }
            _status.Text = "Estado: ACTIVO  |  Equipo: " + Environment.MachineName +
                "  |  Usuario Windows: " + Environment.UserName + "  |  IP: " + ip;
            string content = File.Exists(_logPath) ? File.ReadAllText(_logPath) : "Esperando primer registro...";
            var lines = content.Split(new[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
            _log.Text = string.Join(Environment.NewLine, lines.Reverse().Take(100).Reverse());
            if (!Visible) return;
        }
    }
}
