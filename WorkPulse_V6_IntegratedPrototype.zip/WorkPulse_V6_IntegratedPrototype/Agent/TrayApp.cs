using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace WorkPulse.Agent
{
    internal sealed class TrayApp : IDisposable
    {
        private readonly NotifyIcon _icon;
        private readonly ContextMenuStrip _menu;
        private readonly Timer _timer;
        private readonly MainForm _form;
        private readonly string _dataDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "WorkPulse");
        private readonly string _logPath;
        private bool _disposed;

        public TrayApp()
        {
            Directory.CreateDirectory(_dataDir);
            _logPath = Path.Combine(_dataDir, "agent-heartbeats.jsonl");
            _form = new MainForm(_logPath);
            _menu = new ContextMenuStrip();
            _menu.Items.Add("Abrir WorkPulse", null, (s, e) => ShowForm());
            _menu.Items.Add("Estado: activo", null, (s, e) => MessageBox.Show(
                "WorkPulse está activo en esta sesión de Windows. Esta versión guarda latidos localmente.",
                "WorkPulse", MessageBoxButtons.OK, MessageBoxIcon.Information));
            _menu.Items.Add("Abrir carpeta de datos", null, (s, e) => OpenDataFolder());
            _menu.Items.Add("Iniciar con Windows", null, ToggleStartup);
            _menu.Items.Add(new ToolStripSeparator());
            _menu.Items.Add("Salir", null, (s, e) => Application.Exit());

            _icon = new NotifyIcon
            {
                Icon = SystemIcons.Application,
                Text = "WorkPulse — activo",
                ContextMenuStrip = _menu,
                Visible = true
            };
            _icon.DoubleClick += (s, e) => ShowForm();
            _timer = new Timer { Interval = 60000 };
            _timer.Tick += (s, e) => WriteHeartbeat();
            _timer.Start();
            WriteHeartbeat();
            EnsureStartupShortcut();
            _icon.BalloonTipTitle = "WorkPulse";
            _icon.BalloonTipText = "El agente está activo en la bandeja del sistema.";
            _icon.ShowBalloonTip(2500);
            UpdateStartupLabel();
        }

        private void ShowForm()
        {
            if (_form.IsDisposed) return;
            _form.RefreshStatus();
            _form.Show();
            _form.WindowState = FormWindowState.Normal;
            _form.Activate();
        }

        private void WriteHeartbeat()
        {
            try
            {
                var entry = new
                {
                    timestamp = DateTimeOffset.Now.ToString("o"),
                    machineName = Environment.MachineName,
                    windowsUser = Environment.UserDomainName + "\\" + Environment.UserName,
                    os = Environment.OSVersion.VersionString
                };
                var line = NewtonsoftFreeJson(entry);
                File.AppendAllText(_logPath, line + Environment.NewLine);
            }
            catch { /* Un fallo local de escritura no debe cerrar el agente. */ }
        }

        private static string NewtonsoftFreeJson(object entry)
        {
            // Formato JSONL sencillo, escapando los valores de texto.
            var t = entry.GetType();
            string Get(string name) => Convert.ToString(t.GetProperty(name).GetValue(entry, null));
            string Q(string value) => "\"" + (value ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", "\\r").Replace("\n", "\\n") + "\"";
            return "{\"timestamp\":" + Q(Get("timestamp")) +
                   ",\"machineName\":" + Q(Get("machineName")) +
                   ",\"windowsUser\":" + Q(Get("windowsUser")) +
                   ",\"os\":" + Q(Get("os")) + "}";
        }

        private void ToggleStartup(object sender, EventArgs e)
        {
            string shortcut = StartupShortcutPath();
            if (File.Exists(shortcut))
            {
                File.Delete(shortcut);
            }
            else
            {
                CreateShortcut(shortcut);
            }
            UpdateStartupLabel();
        }

        private void EnsureStartupShortcut()
        {
            string shortcut = StartupShortcutPath();
            if (!File.Exists(shortcut))
            {
                try { CreateShortcut(shortcut); }
                catch (Exception ex)
                {
                    File.AppendAllText(Path.Combine(_dataDir, "startup-error.txt"), ex.ToString());
                }
            }
        }

        private string StartupShortcutPath()
        {
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Startup), "WorkPulse Agent.lnk");
        }

        private void CreateShortcut(string shortcutPath)
        {
            string exe = Process.GetCurrentProcess().MainModule.FileName;
            string script = "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('" +
                shortcutPath.Replace("'", "''") + "');$s.TargetPath='" +
                exe.Replace("'", "''") + "';$s.WorkingDirectory='" +
                Path.GetDirectoryName(exe).Replace("'", "''") + "';$s.Save()";
            var psi = new ProcessStartInfo("powershell.exe",
                "-NoProfile -ExecutionPolicy Bypass -Command \"" + script.Replace("\"", "`\"") + "\"")
            {
                CreateNoWindow = true,
                UseShellExecute = false,
                WindowStyle = ProcessWindowStyle.Hidden
            };
            using (var p = Process.Start(psi))
            {
                p.WaitForExit(5000);
                if (!File.Exists(shortcutPath))
                    throw new InvalidOperationException("No se pudo crear el acceso directo de inicio.");
            }
        }

        private void UpdateStartupLabel()
        {
            foreach (ToolStripItem item in _menu.Items)
                if (item.Text.StartsWith("Iniciar con Windows"))
                    item.Text = File.Exists(StartupShortcutPath())
                        ? "Desactivar inicio con Windows"
                        : "Activar inicio con Windows";
        }

        private void OpenDataFolder()
        {
            Process.Start("explorer.exe", _dataDir);
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            _timer.Stop();
            _timer.Dispose();
            _icon.Visible = false;
            _icon.Dispose();
            _menu.Dispose();
            if (!_form.IsDisposed) _form.Dispose();
        }
    }
}
