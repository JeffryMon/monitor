using System;
using System.Windows.Forms;

namespace WorkPulse.Agent
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            using (var app = new TrayApp())
                Application.Run();
        }
    }
}
