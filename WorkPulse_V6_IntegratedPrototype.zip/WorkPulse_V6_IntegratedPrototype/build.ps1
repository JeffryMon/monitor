$ErrorActionPreference = 'Stop'
$project = Join-Path $PSScriptRoot 'Agent\WorkPulse.Agent.csproj'
$msbuildCandidates = @(
  "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe",
  "$env:ProgramFiles\Microsoft Visual Studio\Installer\vswhere.exe"
)
$vswhere = $msbuildCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $vswhere) {
  Write-Error 'No encuentro vswhere.exe. Instala Visual Studio 2022 o Build Tools con MSBuild.'
}
$install = & $vswhere -latest -products '*' -requires Microsoft.Component.MSBuild -property installationPath
if (-not $install) { Write-Error 'No encuentro una instalación de MSBuild.' }
$msbuild = Join-Path $install 'MSBuild\Current\Bin\MSBuild.exe'
if (-not (Test-Path $msbuild)) { Write-Error "No encuentro MSBuild en $msbuild" }
& $msbuild $project /t:Restore,Build /p:Configuration=Release /v:minimal
if ($LASTEXITCODE -ne 0) { throw "Falló la compilación (código $LASTEXITCODE)." }
Write-Host "`nAgente compilado: $PSScriptRoot\Agent\bin\Release\WorkPulse.Agent.exe" -ForegroundColor Green
