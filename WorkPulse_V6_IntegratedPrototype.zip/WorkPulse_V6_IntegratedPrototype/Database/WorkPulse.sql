/* WorkPulse - esquema inicial SQL Server. Ejecutar en una base nueva de pruebas. */
IF DB_ID(N'WorkPulse') IS NULL CREATE DATABASE WorkPulse;
GO
USE WorkPulse;
GO
IF OBJECT_ID('dbo.Roles','U') IS NULL
CREATE TABLE dbo.Roles(RoleId int IDENTITY PRIMARY KEY, Code varchar(20) NOT NULL UNIQUE, Name nvarchar(80) NOT NULL);
IF OBJECT_ID('dbo.Departments','U') IS NULL
CREATE TABLE dbo.Departments(DepartmentId int IDENTITY PRIMARY KEY, Name nvarchar(120) NOT NULL UNIQUE, IsActive bit NOT NULL DEFAULT 1);
IF OBJECT_ID('dbo.Positions','U') IS NULL
CREATE TABLE dbo.Positions(PositionId int IDENTITY PRIMARY KEY, Name nvarchar(120) NOT NULL UNIQUE, IsActive bit NOT NULL DEFAULT 1);
IF OBJECT_ID('dbo.Users','U') IS NULL
CREATE TABLE dbo.Users(UserId bigint IDENTITY PRIMARY KEY, Username nvarchar(80) NOT NULL UNIQUE, PasswordHash varbinary(256) NOT NULL, PasswordSalt varbinary(64) NOT NULL, IsEnabled bit NOT NULL DEFAULT 1, CreatedAt datetime2 NOT NULL DEFAULT SYSUTCDATETIME(), LastLoginAt datetime2 NULL);
IF OBJECT_ID('dbo.Employees','U') IS NULL
CREATE TABLE dbo.Employees(EmployeeId bigint IDENTITY PRIMARY KEY, UserId bigint NULL REFERENCES dbo.Users(UserId), EmployeeCode nvarchar(40) NULL UNIQUE, FirstName nvarchar(100) NOT NULL, LastName nvarchar(100) NOT NULL, Email nvarchar(200) NULL, Phone nvarchar(40) NULL, DepartmentId int NULL REFERENCES dbo.Departments(DepartmentId), PositionId int NULL REFERENCES dbo.Positions(PositionId), ManagerEmployeeId bigint NULL REFERENCES dbo.Employees(EmployeeId), HireDate date NULL, ScheduleText nvarchar(100) NULL, EmploymentStatus nvarchar(30) NOT NULL DEFAULT N'Activo', Notes nvarchar(1000) NULL, CreatedAt datetime2 NOT NULL DEFAULT SYSUTCDATETIME());
IF OBJECT_ID('dbo.UserRoles','U') IS NULL
CREATE TABLE dbo.UserRoles(UserId bigint NOT NULL REFERENCES dbo.Users(UserId), RoleId int NOT NULL REFERENCES dbo.Roles(RoleId), CONSTRAINT PK_UserRoles PRIMARY KEY(UserId,RoleId));
IF OBJECT_ID('dbo.Devices','U') IS NULL
CREATE TABLE dbo.Devices(DeviceId bigint IDENTITY PRIMARY KEY, DeviceKey uniqueidentifier NOT NULL DEFAULT NEWID(), DeviceName nvarchar(150) NOT NULL, EmployeeId bigint NULL REFERENCES dbo.Employees(EmployeeId), OperatingSystem nvarchar(200) NULL, LastIp varchar(45) NULL, IsEnabled bit NOT NULL DEFAULT 1, PairedAt datetime2 NULL, LastSeenAt datetime2 NULL, CreatedAt datetime2 NOT NULL DEFAULT SYSUTCDATETIME());
IF OBJECT_ID('dbo.DeviceHeartbeats','U') IS NULL
CREATE TABLE dbo.DeviceHeartbeats(HeartbeatId bigint IDENTITY PRIMARY KEY, DeviceId bigint NOT NULL REFERENCES dbo.Devices(DeviceId), SeenAt datetime2 NOT NULL DEFAULT SYSUTCDATETIME(), WindowsSession nvarchar(200) NULL, AgentVersion nvarchar(30) NULL);
IF OBJECT_ID('dbo.WorkSessions','U') IS NULL
CREATE TABLE dbo.WorkSessions(SessionId bigint IDENTITY PRIMARY KEY, EmployeeId bigint NOT NULL REFERENCES dbo.Employees(EmployeeId), DeviceId bigint NULL REFERENCES dbo.Devices(DeviceId), StartedAt datetime2 NOT NULL, EndedAt datetime2 NULL, Source nvarchar(30) NOT NULL DEFAULT N'Agent', Status nvarchar(30) NOT NULL DEFAULT N'Abierta', CreatedAt datetime2 NOT NULL DEFAULT SYSUTCDATETIME());
IF OBJECT_ID('dbo.ActivityEvents','U') IS NULL
CREATE TABLE dbo.ActivityEvents(ActivityId bigint IDENTITY PRIMARY KEY, DeviceId bigint NOT NULL REFERENCES dbo.Devices(DeviceId), EventAt datetime2 NOT NULL DEFAULT SYSUTCDATETIME(), EventType nvarchar(50) NOT NULL, ApplicationName nvarchar(200) NULL, DurationSeconds int NULL, Details nvarchar(1000) NULL);
IF OBJECT_ID('dbo.TimeAdjustmentRequests','U') IS NULL
CREATE TABLE dbo.TimeAdjustmentRequests(RequestId bigint IDENTITY PRIMARY KEY, EmployeeId bigint NOT NULL REFERENCES dbo.Employees(EmployeeId), RequestedDate date NOT NULL, RequestedMinutes int NOT NULL, Reason nvarchar(1000) NOT NULL, Status nvarchar(30) NOT NULL DEFAULT N'Pendiente', RequestedAt datetime2 NOT NULL DEFAULT SYSUTCDATETIME(), ReviewedByUserId bigint NULL REFERENCES dbo.Users(UserId), ReviewedAt datetime2 NULL, ReviewNotes nvarchar(1000) NULL);
IF OBJECT_ID('dbo.AuditLog','U') IS NULL
CREATE TABLE dbo.AuditLog(AuditId bigint IDENTITY PRIMARY KEY, UserId bigint NULL REFERENCES dbo.Users(UserId), EventAt datetime2 NOT NULL DEFAULT SYSUTCDATETIME(), EventType nvarchar(100) NOT NULL, EntityName nvarchar(100) NULL, EntityId nvarchar(100) NULL, Details nvarchar(2000) NULL);
IF NOT EXISTS(SELECT 1 FROM dbo.Roles)
INSERT dbo.Roles(Code,Name) VALUES ('ADMIN',N'Administrador'),('GERENCIA',N'Gerencia'),('JEFE',N'Jefe'),('EMPLEADO',N'Empleado');
GO
