# WorkPulse v0.2 — inscripción automática y credenciales individuales

Starter para Windows + .NET 8 + ASP.NET Core + SQL Server + IIS.

## Cambios de v0.2
- El agente genera y conserva un `DeviceId` GUID automáticamente.
- El agente se inscribe con un código de inscripción de un solo uso.
- La API emite una credencial individual por dispositivo; en SQL Server solo se almacena su hash SHA-256.
- La credencial del agente se protege localmente con Windows DPAPI (CurrentUser).
- La cadena de conexión de SQL Server solo existe en la API.
- Los agentes autentican con `X-WorkPulse-DeviceId` y `X-WorkPulse-Device-Key`.

## Requisitos
- .NET 8 SDK
- SQL Server (Developer/Express para desarrollo)
- Windows 10/11 para el agente
- IIS + ASP.NET Core Hosting Bundle para despliegue de API

## 1. Crear base de datos
Ejecuta `database/001_schema.sql` en SQL Server Management Studio.

## 2. Configurar API
Edita `src/WorkPulse.Api/appsettings.json`:
- `ConnectionStrings:WorkPulse`
- `AdminAuth:ApiKey`: clave administrativa larga y única.
- `Enrollment:CodeLifetimeMinutes`: vigencia de códigos.

No uses el secreto de ejemplo en producción. Configura secretos mediante variables de entorno/gestor de secretos y habilita HTTPS.

## 3. Ejecutar API localmente
Desde `src/WorkPulse.Api`:
```powershell
dotnet restore
dotnet run
```
La API mostrará su URL local. Ajusta `ApiBaseUrl` del agente a esa URL. En desarrollo puede ser `http://localhost:5xxx`; en redes reales usa HTTPS.

## 4. Crear un código de inscripción
En PowerShell, usando la URL y la clave administrativa que configuraste:
```powershell
$adminKey = "TU_CLAVE_ADMINISTRATIVA"
$api = "https://tu-servidor-workpulse"
Invoke-RestMethod -Method Post -Uri "$api/api/admin/enrollment-codes" `
  -Headers @{ "X-WorkPulse-Admin-Key" = $adminKey }
```
La API devuelve el código una sola vez. Compártelo solo con quien vaya a instalar un equipo autorizado. El código expira y solo puede usarse una vez.

## 5. Instalar/ejecutar agente
Edita `src/WorkPulse.Agent/appsettings.json`:
- `ApiBaseUrl`
- `EnrollmentCode` (código generado en el paso anterior)

Desde `src/WorkPulse.Agent`:
```powershell
dotnet restore
dotnet run
```
En el primer inicio el agente genera un DeviceId y se inscribe. Guarda la credencial protegida por DPAPI en `%LOCALAPPDATA%\WorkPulse\identity.dat`. En los siguientes inicios reutiliza la identidad y no vuelve a usar el código. Para registrar de nuevo el equipo, elimina esa carpeta y genera un nuevo código.

Importante: la protección DPAPI CurrentUser implica que el agente debe ejecutarse bajo la misma cuenta de Windows que hizo la inscripción. Si luego se instala como servicio de Windows, migraremos el almacenamiento a DPAPI LocalMachine o al almacén de credenciales del servicio, con ACL restringidas.

## 6. Endpoints
- `GET /health`
- `POST /api/admin/enrollment-codes` — genera un código de un solo uso; requiere clave administrativa.
- `POST /api/agents/enroll` — inscribe un equipo con código válido.
- `POST /api/events` — ingesta autenticada por dispositivo.
- `GET /api/events/recent?take=100` — eventos recientes; requiere credencial de dispositivo.

## Seguridad y privacidad
- Nunca coloques la cadena de conexión de SQL Server en el agente.
- En producción usa HTTPS, una clave administrativa segura, rotación/revocación de credenciales y permisos SQL mínimos.
- El agente de esta versión muestra su actividad en consola.
- No captura pulsaciones, contraseñas, formularios ni audio.
- La recopilación de dominios web y capturas de pantalla permanece deshabilitada y no se implementa en este starter. Debe añadirse solo con autorización explícita, políticas de privacidad, exclusiones y controles de acceso.
- Los títulos de ventanas están deshabilitados por defecto porque pueden contener información sensible.
