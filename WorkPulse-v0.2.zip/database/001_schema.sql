IF DB_ID(N'WorkPulse') IS NULL CREATE DATABASE WorkPulse;
GO
USE WorkPulse;
GO

IF OBJECT_ID(N'dbo.Devices', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Devices (
        DeviceId NVARCHAR(36) NOT NULL CONSTRAINT PK_Devices PRIMARY KEY,
        DisplayName NVARCHAR(200) NOT NULL,
        OperatingSystem NVARCHAR(100) NOT NULL CONSTRAINT DF_Devices_OS DEFAULT N'Windows',
        AgentVersion NVARCHAR(40) NULL,
        CredentialHash VARBINARY(32) NOT NULL,
        FirstSeenUtc DATETIME2(3) NOT NULL CONSTRAINT DF_Devices_FirstSeen DEFAULT SYSUTCDATETIME(),
        LastSeenUtc DATETIME2(3) NULL,
        IsEnabled BIT NOT NULL CONSTRAINT DF_Devices_Enabled DEFAULT 1
    );
END;
GO

IF OBJECT_ID(N'dbo.EnrollmentCodes', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.EnrollmentCodes (
        EnrollmentCodeId BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_EnrollmentCodes PRIMARY KEY,
        CodeHash VARBINARY(32) NOT NULL,
        CreatedAtUtc DATETIME2(3) NOT NULL CONSTRAINT DF_EnrollmentCodes_Created DEFAULT SYSUTCDATETIME(),
        ExpiresAtUtc DATETIME2(3) NOT NULL,
        UsedAtUtc DATETIME2(3) NULL,
        UsedByDeviceId NVARCHAR(36) NULL,
        CONSTRAINT UQ_EnrollmentCodes_CodeHash UNIQUE(CodeHash)
    );
END;
GO

IF OBJECT_ID(N'dbo.ActivityEvents', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ActivityEvents (
        EventId BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ActivityEvents PRIMARY KEY,
        EventGuid UNIQUEIDENTIFIER NOT NULL,
        DeviceId NVARCHAR(36) NOT NULL,
        UserName NVARCHAR(256) NULL,
        EventType NVARCHAR(40) NOT NULL,
        ApplicationName NVARCHAR(260) NULL,
        WindowTitle NVARCHAR(500) NULL,
        Domain NVARCHAR(253) NULL,
        IsIdle BIT NOT NULL CONSTRAINT DF_ActivityEvents_IsIdle DEFAULT 0,
        DurationSeconds INT NOT NULL CONSTRAINT DF_ActivityEvents_Duration DEFAULT 0,
        OccurredAtUtc DATETIME2(3) NOT NULL,
        ReceivedAtUtc DATETIME2(3) NOT NULL CONSTRAINT DF_ActivityEvents_Received DEFAULT SYSUTCDATETIME(),
        CONSTRAINT UQ_ActivityEvents_EventGuid UNIQUE(EventGuid),
        CONSTRAINT FK_ActivityEvents_Devices FOREIGN KEY(DeviceId) REFERENCES dbo.Devices(DeviceId),
        CONSTRAINT CK_ActivityEvents_Duration CHECK (DurationSeconds >= 0)
    );
    CREATE INDEX IX_ActivityEvents_Device_OccurredAt ON dbo.ActivityEvents(DeviceId, OccurredAtUtc DESC);
    CREATE INDEX IX_ActivityEvents_Type_OccurredAt ON dbo.ActivityEvents(EventType, OccurredAtUtc DESC);
END;
GO
