namespace WorkPulse.Api.Models;

public sealed record EnrollRequest(string EnrollmentCode, string DeviceId, string DisplayName, string OperatingSystem, string? AgentVersion);
public sealed record EnrollResponse(string DeviceId, string DeviceCredential, string Message);
public sealed record EnrollmentCodeResponse(string EnrollmentCode, DateTime ExpiresAtUtc);
public sealed class ActivityEventInput
{
    public Guid EventGuid { get; set; }
    public string DeviceId { get; set; } = "";
    public string? UserName { get; set; }
    public string EventType { get; set; } = "activity";
    public string? ApplicationName { get; set; }
    public string? WindowTitle { get; set; }
    public bool IsIdle { get; set; }
    public int DurationSeconds { get; set; }
    public DateTime OccurredAtUtc { get; set; }
}
