namespace WorkPulse.Api.Models;

public sealed class EnrollmentCode
{
    public long EnrollmentCodeId { get; set; }
    public byte[] CodeHash { get; set; } = [];
    public DateTime CreatedAtUtc { get; set; }
    public DateTime ExpiresAtUtc { get; set; }
    public DateTime? UsedAtUtc { get; set; }
    public string? UsedByDeviceId { get; set; }
}
