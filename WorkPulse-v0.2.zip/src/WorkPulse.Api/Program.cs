using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using WorkPulse.Api.Data;
using WorkPulse.Api.Models;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<WorkPulseDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("WorkPulse")));
builder.Services.AddCors(options =>
{
    options.AddPolicy("Dashboard", policy =>
        policy.WithOrigins(builder.Configuration["Dashboard:AllowedOrigin"] ?? "http://localhost:5500")
              .AllowAnyHeader().AllowAnyMethod());
});
var app = builder.Build();
app.UseCors("Dashboard");

string Hash(string value) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(value)));

bool FixedTimeEqualsText(string expected, string supplied)
{
    var a = Encoding.UTF8.GetBytes(expected);
    var b = Encoding.UTF8.GetBytes(supplied);
    return a.Length == b.Length && CryptographicOperations.FixedTimeEquals(a, b);
}

bool IsAdmin(HttpRequest request)
{
    var expected = builder.Configuration["AdminAuth:ApiKey"] ?? "";
    var supplied = request.Headers["X-WorkPulse-Admin-Key"].ToString();
    return expected.Length >= 32 &&
           expected != "REPLACE_WITH_A_LONG_RANDOM_ADMIN_SECRET" &&
           FixedTimeEqualsText(expected, supplied);
}

async Task<Device?> AuthenticateDevice(HttpRequest request, WorkPulseDbContext db)
{
    var deviceId = request.Headers["X-WorkPulse-DeviceId"].ToString();
    var credential = request.Headers["X-WorkPulse-Device-Key"].ToString();
    if (string.IsNullOrWhiteSpace(deviceId) || string.IsNullOrWhiteSpace(credential)) return null;
    var device = await db.Devices.FindAsync(deviceId);
    if (device is null || !device.IsEnabled) return null;
    var suppliedHash = SHA256.HashData(Encoding.UTF8.GetBytes(credential));
    if (device.CredentialHash.Length != suppliedHash.Length ||
        !CryptographicOperations.FixedTimeEquals(device.CredentialHash, suppliedHash)) return null;
    return device;
}

app.MapGet("/health", () => Results.Ok(new { status = "ok", service = "WorkPulse.Api", version = "0.2" }));

app.MapPost("/api/admin/enrollment-codes", async (HttpRequest request, WorkPulseDbContext db) =>
{
    if (!IsAdmin(request)) return Results.Unauthorized();
    var minutes = Math.Clamp(builder.Configuration.GetValue<int>("Enrollment:CodeLifetimeMinutes", 30), 5, 1440);
    var code = Convert.ToBase64String(RandomNumberGenerator.GetBytes(24))
        .Replace("+", "-").Replace("/", "_").TrimEnd('=');
    var expires = DateTime.UtcNow.AddMinutes(minutes);
    db.EnrollmentCodes.Add(new EnrollmentCode {
        CodeHash = SHA256.HashData(Encoding.UTF8.GetBytes(code)),
        CreatedAtUtc = DateTime.UtcNow,
        ExpiresAtUtc = expires
    });
    await db.SaveChangesAsync();
    return Results.Ok(new EnrollmentCodeResponse(code, expires));
});

app.MapPost("/api/agents/enroll", async (EnrollRequest input, WorkPulseDbContext db) =>
{
    if (string.IsNullOrWhiteSpace(input.EnrollmentCode) ||
        string.IsNullOrWhiteSpace(input.DeviceId) || input.DeviceId.Length > 36 ||
        string.IsNullOrWhiteSpace(input.DisplayName) || input.DisplayName.Length > 200)
        return Results.BadRequest(new { error = "Datos de inscripción inválidos." });

    var codeHash = SHA256.HashData(Encoding.UTF8.GetBytes(input.EnrollmentCode));
    var enrollment = await db.EnrollmentCodes.SingleOrDefaultAsync(x => x.CodeHash == codeHash);
    var now = DateTime.UtcNow;
    if (enrollment is null || enrollment.UsedAtUtc is not null || enrollment.ExpiresAtUtc <= now)
        return Results.Unauthorized();

    if (await db.Devices.AnyAsync(d => d.DeviceId == input.DeviceId))
        return Results.Conflict(new { error = "El DeviceId ya está registrado." });

    var credential = Convert.ToBase64String(RandomNumberGenerator.GetBytes(32))
        .Replace("+", "-").Replace("/", "_").TrimEnd('=');
    var device = new Device {
        DeviceId = input.DeviceId,
        DisplayName = input.DisplayName,
        OperatingSystem = string.IsNullOrWhiteSpace(input.OperatingSystem) ? "Windows" : input.OperatingSystem[..Math.Min(input.OperatingSystem.Length, 100)],
        AgentVersion = input.AgentVersion,
        CredentialHash = SHA256.HashData(Encoding.UTF8.GetBytes(credential)),
        FirstSeenUtc = now,
        LastSeenUtc = now,
        IsEnabled = true
    };
    enrollment.UsedAtUtc = now;
    enrollment.UsedByDeviceId = input.DeviceId;
    db.Devices.Add(device);
    await db.SaveChangesAsync();
    // La credencial solo se devuelve durante la inscripción; la base conserva únicamente su hash.
    return Results.Ok(new EnrollResponse(device.DeviceId, credential, "Guarda esta credencial: no se volverá a mostrar."));
});

app.MapPost("/api/events", async (HttpRequest request, ActivityEventInput input, WorkPulseDbContext db) =>
{
    var device = await AuthenticateDevice(request, db);
    if (device is null) return Results.Unauthorized();
    if (!string.Equals(input.DeviceId, device.DeviceId, StringComparison.Ordinal))
        return Results.Forbid();
    if (string.IsNullOrWhiteSpace(input.EventType) || input.EventType.Length > 40)
        return Results.BadRequest(new { error = "EventType es obligatorio y máximo 40 caracteres." });
    if (input.DurationSeconds < 0 || input.DurationSeconds > 86400)
        return Results.BadRequest(new { error = "DurationSeconds fuera de rango." });

    var eventGuid = input.EventGuid == Guid.Empty ? Guid.NewGuid() : input.EventGuid;
    if (await db.ActivityEvents.AnyAsync(e => e.EventGuid == eventGuid))
        return Results.Ok(new { duplicate = true });

    device.LastSeenUtc = DateTime.UtcNow;
    db.ActivityEvents.Add(new ActivityEvent {
        EventGuid = eventGuid,
        DeviceId = device.DeviceId,
        UserName = input.UserName,
        EventType = input.EventType,
        ApplicationName = input.ApplicationName,
        WindowTitle = input.WindowTitle,
        Domain = null,
        IsIdle = input.IsIdle,
        DurationSeconds = input.DurationSeconds,
        OccurredAtUtc = input.OccurredAtUtc == default ? DateTime.UtcNow : input.OccurredAtUtc.ToUniversalTime(),
        ReceivedAtUtc = DateTime.UtcNow
    });
    await db.SaveChangesAsync();
    return Results.Accepted();
});

app.MapGet("/api/events/recent", async (HttpRequest request, int? take, WorkPulseDbContext db) =>
{
    if (await AuthenticateDevice(request, db) is null) return Results.Unauthorized();
    var count = Math.Clamp(take ?? 50, 1, 200);
    var rows = await db.ActivityEvents.AsNoTracking()
        .OrderByDescending(e => e.OccurredAtUtc).Take(count)
        .Select(e => new { e.EventId, e.DeviceId, e.UserName, e.EventType, e.ApplicationName,
            e.WindowTitle, e.IsIdle, e.DurationSeconds, e.OccurredAtUtc, e.ReceivedAtUtc })
        .ToListAsync();
    return Results.Ok(rows);
});

app.Run();
