using System.Diagnostics;
using System.Net.Http.Json;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

if (!OperatingSystem.IsWindows())
{
    Console.Error.WriteLine("WorkPulse.Agent requiere Windows.");
    return;
}

var configPath = Path.Combine(AppContext.BaseDirectory, "appsettings.json");
if (!File.Exists(configPath))
{
    Console.Error.WriteLine($"No se encontró configuración: {configPath}");
    return;
}
using var configDoc = JsonDocument.Parse(await File.ReadAllTextAsync(configPath));
var root = configDoc.RootElement;
var apiBaseUrl = root.GetProperty("ApiBaseUrl").GetString() ?? "";
var enrollmentCode = root.GetProperty("EnrollmentCode").GetString() ?? "";
var pollSeconds = Math.Clamp(root.GetProperty("PollIntervalSeconds").GetInt32(), 10, 300);
var idleThreshold = Math.Clamp(root.GetProperty("IdleThresholdSeconds").GetInt32(), 60, 3600);
var captureTitles = root.GetProperty("CaptureWindowTitles").GetBoolean();

using var client = new HttpClient { BaseAddress = new Uri(apiBaseUrl.TrimEnd('/') + "/") };
var identityDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "WorkPulse");
var identityPath = Path.Combine(identityDir, "identity.dat");
Directory.CreateDirectory(identityDir);
var identity = await LoadIdentityAsync(identityPath);

if (identity is null)
{
    if (string.IsNullOrWhiteSpace(enrollmentCode) || enrollmentCode == "PASTE_ONE_TIME_ENROLLMENT_CODE_HERE")
    {
        Console.Error.WriteLine("Configura un código de inscripción de un solo uso en appsettings.json.");
        return;
    }
    identity = new AgentIdentity {
        DeviceId = Guid.NewGuid().ToString(),
        DeviceCredential = ""
    };
    var request = new EnrollRequest(
        enrollmentCode,
        identity.DeviceId,
        Environment.MachineName,
        "Windows",
        "0.2.0");
    using var enrollResponse = await client.PostAsJsonAsync("api/agents/enroll", request);
    if (!enrollResponse.IsSuccessStatusCode)
    {
        Console.Error.WriteLine($"Inscripción fallida: HTTP {(int)enrollResponse.StatusCode}. Comprueba URL y código (vigente y no usado).");
        return;
    }
    var result = await enrollResponse.Content.ReadFromJsonAsync<EnrollResponse>();
    if (result is null || string.IsNullOrWhiteSpace(result.DeviceCredential))
    {
        Console.Error.WriteLine("La API no devolvió una credencial válida.");
        return;
    }
    identity.DeviceId = result.DeviceId;
    identity.DeviceCredential = result.DeviceCredential;
    await SaveIdentityAsync(identityPath, identity);
    Console.WriteLine($"Equipo inscrito: {identity.DeviceId}");
    Console.WriteLine("La credencial individual se guardó protegida con Windows DPAPI.");
}
else
{
    Console.WriteLine($"Identidad existente cargada: {identity.DeviceId}");
}

client.DefaultRequestHeaders.Add("X-WorkPulse-DeviceId", identity.DeviceId);
client.DefaultRequestHeaders.Add("X-WorkPulse-Device-Key", identity.DeviceCredential);

using var stop = new CancellationTokenSource();
Console.CancelKeyPress += (_, e) => { e.Cancel = true; stop.Cancel(); };
Console.WriteLine("WorkPulse Agent activo y visible. Ctrl+C para detener.");
Console.WriteLine($"Equipo: {Environment.MachineName}; intervalo: {pollSeconds}s.");
Console.WriteLine("Dominios web y capturas de pantalla están deshabilitados.");

try
{
    while (!stop.IsCancellationRequested)
    {
        var now = DateTime.UtcNow;
        var idleSeconds = WindowsActivity.GetIdleSeconds();
        var appName = WindowsActivity.GetForegroundProcessName();
        var title = captureTitles ? WindowsActivity.GetForegroundWindowTitle() : null;
        var isIdle = idleSeconds >= idleThreshold;
        var payload = new ActivityPayload {
            EventGuid = Guid.NewGuid(),
            DeviceId = identity.DeviceId,
            UserName = Environment.UserName,
            EventType = isIdle ? "idle" : "application_activity",
            ApplicationName = isIdle ? null : appName,
            WindowTitle = isIdle ? null : title,
            IsIdle = isIdle,
            DurationSeconds = pollSeconds,
            OccurredAtUtc = now
        };
        try
        {
            using var response = await client.PostAsJsonAsync("api/events", payload, stop.Token);
            if (!response.IsSuccessStatusCode)
                Console.WriteLine($"{now:HH:mm:ss} API respondió HTTP {(int)response.StatusCode}.");
            else
                Console.WriteLine($"{now:HH:mm:ss} Evento enviado: {(isIdle ? "inactivo" : appName ?? "desconocido")}.");
        }
        catch (OperationCanceledException) when (stop.IsCancellationRequested) { break; }
        catch (Exception ex) { Console.WriteLine($"Error de envío: {ex.Message}"); }

        await Task.Delay(TimeSpan.FromSeconds(pollSeconds), stop.Token);
    }
}
catch (OperationCanceledException) { }
Console.WriteLine("WorkPulse Agent detenido.");

static async Task<AgentIdentity?> LoadIdentityAsync(string path)
{
    if (!File.Exists(path)) return null;
    try
    {
        var encrypted = await File.ReadAllBytesAsync(path);
        var json = ProtectedData.Unprotect(encrypted, null, DataProtectionScope.CurrentUser);
        return JsonSerializer.Deserialize<AgentIdentity>(json);
    }
    catch
    {
        Console.Error.WriteLine("No se pudo descifrar la identidad local. ¿Cambió la cuenta de Windows o se dañó identity.dat?");
        return null;
    }
}

static async Task SaveIdentityAsync(string path, AgentIdentity identity)
{
    var json = JsonSerializer.SerializeToUtf8Bytes(identity);
    var encrypted = ProtectedData.Protect(json, null, DataProtectionScope.CurrentUser);
    await File.WriteAllBytesAsync(path, encrypted);
}

public sealed class AgentIdentity
{
    public string DeviceId { get; set; } = "";
    public string DeviceCredential { get; set; } = "";
}
public sealed record EnrollRequest(string EnrollmentCode, string DeviceId, string DisplayName, string OperatingSystem, string? AgentVersion);
public sealed record EnrollResponse(string DeviceId, string DeviceCredential, string Message);
public sealed class ActivityPayload
{
    public Guid EventGuid { get; set; }
    public string DeviceId { get; set; } = "";
    public string? UserName { get; set; }
    public string EventType { get; set; } = "";
    public string? ApplicationName { get; set; }
    public string? WindowTitle { get; set; }
    public bool IsIdle { get; set; }
    public int DurationSeconds { get; set; }
    public DateTime OccurredAtUtc { get; set; }
}

internal static class WindowsActivity
{
    [StructLayout(LayoutKind.Sequential)]
    private struct LASTINPUTINFO { public uint cbSize; public uint dwTime; }
    [DllImport("user32.dll")] private static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);
    [DllImport("user32.dll")] private static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);
    [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);

    public static int GetIdleSeconds()
    {
        var info = new LASTINPUTINFO { cbSize = (uint)Marshal.SizeOf<LASTINPUTINFO>() };
        if (!GetLastInputInfo(ref info)) return 0;
        var elapsed = unchecked((uint)Environment.TickCount - info.dwTime);
        return (int)(elapsed / 1000);
    }
    public static string? GetForegroundProcessName()
    {
        var hwnd = GetForegroundWindow();
        if (hwnd == IntPtr.Zero) return null;
        GetWindowThreadProcessId(hwnd, out var pid);
        try { return Process.GetProcessById((int)pid).ProcessName; } catch { return null; }
    }
    public static string? GetForegroundWindowTitle()
    {
        var hwnd = GetForegroundWindow();
        if (hwnd == IntPtr.Zero) return null;
        var buffer = new StringBuilder(1024);
        _ = GetWindowText(hwnd, buffer, buffer.Capacity);
        var value = buffer.ToString();
        return string.IsNullOrWhiteSpace(value) ? null : value[..Math.Min(value.Length, 500)];
    }
}
