using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkPulse.Agent
{
    internal sealed class MainForm : Form
    {
        private readonly string logPath;
        private readonly Label status = new Label();
        private readonly TextBox logs = new TextBox();
        private readonly Func<Task> testSend;
        private readonly Button sendButton = new Button();

        public MainForm(string path, Func<Task> sendAction)
        {
            logPath = path;
            testSend = sendAction;

            Text = "WorkPulse — agente";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(720, 500);
            MinimumSize = new Size(620, 420);
            Font = new Font("Segoe UI", 9);

            var title = new Label
            {
                Text = "WorkPulse",
                Font = new Font("Segoe UI", 19, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(22, 18)
            };

            status.SetBounds(24, 60, 660, 40);
            status.Text = "Inicializando...";

            logs.Multiline = true;
            logs.ReadOnly = true;
            logs.ScrollBars = ScrollBars.Vertical;
            logs.SetBounds(24, 112, 660, 290);

            sendButton.Text = "Enviar latido de prueba";
            sendButton.Location = new Point(24, 414);
            sendButton.Size = new Size(190, 30);
            sendButton.Click += async (sender, e) =>
            {
                sendButton.Enabled = false;
                try
                {
                    await testSend();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(
                        "Error al enviar: " + ex.Message,
                        "WorkPulse",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
                finally
                {
                    sendButton.Enabled = true;
                }
            };

            Controls.AddRange(new Control[] { title, status, logs, sendButton });
            RefreshStatus();
        }

        public void SetConnectionStatus(string message)
        {
            if (IsDisposed) return;
            if (InvokeRequired)
            {
                BeginInvoke(new Action(() => SetConnectionStatus(message)));
                return;
            }

            status.Text = "Estado del último envío: " + message;
            RefreshStatus();
        }

        public void RefreshStatus()
        {
            if (IsDisposed) return;
            var lines = File.Exists(logPath) ? File.ReadAllLines(logPath) : new string[0];
            logs.Text = string.Join(Environment.NewLine, lines.Reverse().Take(100).Reverse());
        }
    }
}
