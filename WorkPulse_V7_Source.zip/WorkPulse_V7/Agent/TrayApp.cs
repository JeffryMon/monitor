using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace WorkPulse.Agent
{
    internal sealed class TrayApp : IDisposable
    {
        [StructLayout(LayoutKind.Sequential)] private struct LASTINPUTINFO { public uint cbSize; public uint dwTime; }
        [DllImport("user32.dll")] private static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);
        private readonly NotifyIcon icon; private readonly ContextMenuStrip menu; private readonly Timer timer;
        private readonly MainForm form; private readonly HttpClient http = new HttpClient();
        private readonly JavaScriptSerializer json = new JavaScriptSerializer();
        private readonly string dataDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"WorkPulse");
        private readonly string logPath; private string apiUrl=""; private string deviceToken=""; private bool sending;
        public TrayApp()
        {
            Directory.CreateDirectory(dataDir); logPath=Path.Combine(dataDir,"agent-log.jsonl");
            LoadSettings();
            form=new MainForm(logPath,()=>SendHeartbeat());
            menu=new ContextMenuStrip();
            menu.Items.Add("Abrir WorkPulse",null,(s,e)=>ShowForm());
            menu.Items.Add("Enviar prueba ahora",null,async(s,e)=>await SendHeartbeat());
            menu.Items.Add("Abrir carpeta de registros",null,(s,e)=>Process.Start("explorer.exe",dataDir));
            menu.Items.Add("Iniciar con Windows",null,ToggleStartup);
            menu.Items.Add(new ToolStripSeparator()); menu.Items.Add("Salir",null,(s,e)=>Application.Exit());
            icon=new NotifyIcon{Icon=SystemIcons.Application,Text="WorkPulse — agente activo",Visible=true,ContextMenuStrip=menu};
            icon.DoubleClick+=(s,e)=>ShowForm();
            timer=new Timer{Interval=60000}; timer.Tick+=async(s,e)=>await SendHeartbeat(); timer.Start();
            EnsureStartup(); Append("AGENT_STARTED","El agente inició en esta sesión.");
            icon.BalloonTipTitle="WorkPulse";icon.BalloonTipText="Agente activo. Revisa el estado desde el icono de la bandeja.";icon.ShowBalloonTip(2500);
            UpdateStartupLabel(); _=SendHeartbeat();
        }
        private void LoadSettings()
        {
            try { var p=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"agentsettings.json"); if(!File.Exists(p))return;
                var x=json.Deserialize<Dictionary<string,string>>(File.ReadAllText(p)); if(x!=null){string v; if(x.TryGetValue("ApiBaseUrl",out v))apiUrl=v??""; if(x.TryGetValue("DeviceToken",out v))deviceToken=v??"";} }
            catch(Exception ex){Append("CONFIG_ERROR",ex.Message);}
        }
        private string CurrentProcess()
        {
            try { var h=GetForegroundWindow(); uint pid; GetWindowThreadProcessId(h,out pid); return Process.GetProcessById((int)pid).ProcessName; }
            catch{return "";}
        }
        [DllImport("user32.dll")] private static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr hWnd,out uint processId);
        private bool IsIdle()
        {
            var info=new LASTINPUTINFO{cbSize=(uint)Marshal.SizeOf(typeof(LASTINPUTINFO))};
            return GetLastInputInfo(ref info) && unchecked((uint)Environment.TickCount-info.dwTime)>5*60*1000;
        }
        private async Task SendHeartbeat()
        {
            if(sending)return; sending=true;
            string result="No enviado";
            try
            {
                if(string.IsNullOrWhiteSpace(apiUrl)||string.IsNullOrWhiteSpace(deviceToken)||deviceToken.StartsWith("CONFIGURA_"))
                    throw new InvalidOperationException("Configura ApiBaseUrl y DeviceToken en agentsettings.json.");
                var body=new {machineName=Environment.MachineName,windowsUser=Environment.UserDomainName+"\\"+Environment.UserName,operatingSystem=Environment.OSVersion.VersionString,processName=CurrentProcess(),isIdle=IsIdle()};
                var content=new StringContent(json.Serialize(body),Encoding.UTF8,"application/json");
                http.DefaultRequestHeaders.Remove("X-Device-Token");http.DefaultRequestHeaders.Add("X-Device-Token",deviceToken);
                var response=await http.PostAsync(new Uri(new Uri(apiUrl), "api/agent/heartbeat"),content);
                result=((int)response.StatusCode)+" "+response.ReasonPhrase;
                response.EnsureSuccessStatusCode();Append("HEARTBEAT_OK",json.Serialize(body));
            }
            catch(Exception ex){Append("HEARTBEAT_ERROR",ex.Message);result=ex.Message;}
            finally{sending=false;if(!form.IsDisposed)form.SetConnectionStatus(result);}
        }
        private void Append(string kind,string detail){try{File.AppendAllText(logPath,DateTimeOffset.Now.ToString("o")+" "+kind+" "+detail.Replace("\r"," ").Replace("\n"," ")+Environment.NewLine);}catch{}}
        private void ShowForm(){if(form.IsDisposed)return;form.RefreshStatus();form.Show();form.WindowState=FormWindowState.Normal;form.Activate();}
        private string ShortcutPath()=>Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Startup),"WorkPulse Agent.lnk");
        private void EnsureStartup(){try{if(!File.Exists(ShortcutPath()))CreateShortcut();}catch(Exception ex){Append("STARTUP_ERROR",ex.Message);}}
        private void CreateShortcut()
        {
            string shortcut=ShortcutPath(),exe=Process.GetCurrentProcess().MainModule.FileName;
            string script="$s=(New-Object -ComObject WScript.Shell).CreateShortcut('"+shortcut.Replace("'","''")+"');$s.TargetPath='"+exe.Replace("'","''")+"';$s.WorkingDirectory='"+Path.GetDirectoryName(exe).Replace("'","''")+"';$s.Save()";
            using(var p=Process.Start(new ProcessStartInfo("powershell.exe","-NoProfile -ExecutionPolicy Bypass -Command \""+script.Replace("\"","`\"")+"\""){CreateNoWindow=true,UseShellExecute=false,WindowStyle=ProcessWindowStyle.Hidden})){p.WaitForExit(5000);}
            if(!File.Exists(shortcut))throw new Exception("No se pudo crear el acceso directo.");
        }
        private void ToggleStartup(object s,EventArgs e){try{if(File.Exists(ShortcutPath()))File.Delete(ShortcutPath());else CreateShortcut();UpdateStartupLabel();}catch(Exception ex){MessageBox.Show(ex.Message,"WorkPulse");}}
        private void UpdateStartupLabel(){foreach(ToolStripItem i in menu.Items)if(i.Text.StartsWith("Iniciar con Windows"))i.Text=File.Exists(ShortcutPath())?"Desactivar inicio con Windows":"Activar inicio con Windows";}
        public void Dispose(){timer.Stop();timer.Dispose();icon.Visible=false;icon.Dispose();menu.Dispose();http.Dispose();if(!form.IsDisposed)form.Dispose();}
    }
}
