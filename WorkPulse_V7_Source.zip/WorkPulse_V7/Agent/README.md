# Agente WorkPulse
- Compilar `WorkPulse.Agent.csproj` en Visual Studio sobre Windows con .NET Framework 4.7.2 Developer Pack.
- Copiar `agentsettings.json` junto al EXE y configurar `ApiBaseUrl` y `DeviceToken`.
- El servidor debe tener un registro en `Devices` cuyo `DeviceTokenHash` sea el SHA-256 en hexadecimal del token.
- Inicio automático por usuario actual usando la carpeta Startup.
- Envía cada minuto equipo, usuario de sesión, sistema operativo, proceso activo e indicador de inactividad (5 minutos).
- No registra teclas, texto escrito, capturas ni contenido de ventanas.
