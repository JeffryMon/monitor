# WorkPulse V7 — base integrada (fuente)

Esta versión reemplaza la maqueta local por una base de arquitectura centralizada:
- API ASP.NET Core 8 + SQL Server.
- Login con contraseñas hash y JWT.
- Primer administrador mediante endpoint de instalación protegido por secreto.
- Roles Admin, Gerencia, Jefe y Empleado.
- Solicitudes de ajuste y decisión del jefe/gerencia.
- Reporte XLSX con ClosedXML.
- Portal web servido por la API, con modales propios y sin datos demo automáticos.
- Agente Windows de bandeja .NET Framework 4.7.2, con configuración de API/token, heartbeat y nombre del proceso en primer plano (sin teclas, capturas ni contenido de ventanas).

## Importante
Esta entrega es **código fuente de una base funcional para integración y pruebas controladas**, no un producto certificado listo para desplegar sin revisión. No se adjunta un EXE precompilado y verificado porque aquí no hay compilador Windows/.NET Framework. Debes compilar el agente en Windows y probar la solución con tu SQL Server.
Antes de producción: HTTPS obligatorio, cambiar secretos, revisar permisos/retención, políticas de privacidad, copias de seguridad, pruebas de carga/seguridad, servicio de correo/flujo de restablecimiento y despliegue con migraciones versionadas. El restablecimiento de contraseña en esta base es administrativo; no incluye correo de recuperación.

## Requisitos
- Windows para compilar y ejecutar el agente.
- .NET 8 SDK para API.
- .NET Framework 4.7.2 Developer Pack para el agente.
- SQL Server 2016+ recomendado (ajusta compatibilidad si usas una versión anterior).

## 1. Configurar SQL Server
Edita `Api/appsettings.json`:
- `ConnectionStrings:WorkPulse`: servidor, base y credenciales.
- `Jwt:SigningKey`: reemplaza por una clave aleatoria larga.
- `Bootstrap:SetupSecret`: reemplaza por un secreto de instalación largo.

La API crea las tablas al arrancar si la base está vacía (`EnsureCreated`). Para instalaciones con datos existentes, no uses este mecanismo como migración: genera y aplica migraciones EF Core versionadas. El script `Database/WorkPulse.sql` es una referencia del modelo y no debe ejecutarse encima de una base existente sin revisar.

## 2. Ejecutar API + portal
Desde la carpeta raíz:
```powershell
dotnet restore .\Api\WorkPulse.Api.csproj
dotnet run --project .\Api\WorkPulse.Api.csproj
```
Abre la URL HTTPS/HTTP que muestre la consola; normalmente el portal se sirve en la raíz y Swagger en `/swagger` solo en Development.

### Crear primer administrador (no se generan usuarios de prueba)
Usa PowerShell en la misma máquina:
```powershell
$body = @{
  username = "admin"
  password = "CAMBIA-ESTA-CLAVE-LARGA"
  firstName = "Administrador"
  lastName = "WorkPulse"
  email = "admin@tuempresa.local"
} | ConvertTo-Json
Invoke-RestMethod -Method Post -Uri "http://localhost:5080/api/setup/first-admin" `
  -Headers @{ "X-Setup-Secret" = "EL-VALOR-DE-Bootstrap-SetupSecret" } `
  -ContentType "application/json" -Body $body
```
Usa la URL/puerto que indique tu consola. En producción, elimina o deshabilita el endpoint de bootstrap tras crear el primer administrador.

## 3. Compilar agente Windows
Abre `Agent/WorkPulse.Agent.csproj` en Visual Studio. Compila `Release`. El EXE quedará en `Agent\bin\Release\WorkPulse.Agent.exe`.
Edita `Agent/agentsettings.json` y colócalo junto al EXE:
- `ApiBaseUrl`: URL base de la API, terminada en `/`.
- `DeviceToken`: token de dispositivo registrado por administración en SQL/API.

El agente registra automáticamente inicio de sesión en la carpeta Startup del usuario actual. Eso significa que inicia cuando el usuario inicia sesión, no antes de la pantalla de inicio de Windows. No está diseñado como servicio de Windows.

### Token del agente
Registra un dispositivo en `dbo.Devices`, asigna un `DeviceToken` aleatorio de alta entropía y almacena el hash del token en `DeviceTokenHash`. El agente manda el token por cabecera `X-Device-Token`. En este código de base, el token en claro no se genera ni se muestra desde el portal; hay que provisionarlo de forma segura. No reutilices un token de ejemplo.

## Funciones de API
- `POST /api/auth/login`
- `POST /api/setup/first-admin`
- `GET /api/me`
- `GET /api/dashboard/me`
- `GET /api/dashboard/management`
- `GET /api/users` / `POST /api/users`
- `POST /api/users/{id}/reset-password`
- `GET /api/time-requests`
- `POST /api/time-requests`
- `POST /api/time-requests/{id}/decision`
- `GET /api/reports/attendance.xlsx?from=YYYY-MM-DD&to=YYYY-MM-DD`
- `POST /api/agent/heartbeat` (X-Device-Token)

## Privacidad y precisión
El agente solo registra latidos, equipo, usuario de sesión, nombre del proceso activo e indicador de inactividad. No registra pulsaciones de teclado, contenido escrito ni capturas de pantalla. Los horarios y umbrales deben configurarse por organización y verificarse antes de usar los reportes para decisiones laborales.
