/* Esquema de referencia. La API puede crear las tablas iniciales en una base vacía.
   No ejecutes este script sobre bases con datos sin revisar y respaldar primero. */
IF DB_ID(N'WorkPulse') IS NULL CREATE DATABASE WorkPulse;
GO
USE WorkPulse;
GO
CREATE TABLE dbo.Users (
 Id int IDENTITY PRIMARY KEY, Username nvarchar(80) NOT NULL UNIQUE, PasswordHash nvarchar(200) NOT NULL,
 FirstName nvarchar(100) NOT NULL, LastName nvarchar(100) NOT NULL, Email nvarchar(200) NOT NULL DEFAULT '',
 Department nvarchar(100) NOT NULL DEFAULT '', Position nvarchar(100) NOT NULL DEFAULT '', ManagerId int NULL,
 Role nvarchar(30) NOT NULL, EmploymentStatus nvarchar(30) NOT NULL DEFAULT 'Activo',
 ScheduleStart varchar(30) NOT NULL DEFAULT '08:00:00', ScheduleEnd varchar(30) NOT NULL DEFAULT '17:00:00',
 CreatedAtUtc datetime2 NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE dbo.Devices (
 Id int IDENTITY PRIMARY KEY, DeviceName nvarchar(100) NOT NULL, DeviceTokenHash nvarchar(200) NOT NULL,
 EmployeeId int NULL, OperatingSystem nvarchar(200) NOT NULL DEFAULT '', LastSeenUtc datetime2 NULL, IsEnabled bit NOT NULL DEFAULT 1
);
CREATE TABLE dbo.AgentEvents (
 Id bigint IDENTITY PRIMARY KEY, DeviceId int NOT NULL, EventAtUtc datetime2 NOT NULL, WindowsUser nvarchar(200) NOT NULL,
 MachineName nvarchar(100) NOT NULL, OperatingSystem nvarchar(200) NOT NULL, ProcessName nvarchar(200) NOT NULL, IsIdle bit NOT NULL
);
CREATE TABLE dbo.TimeRequests (
 Id int IDENTITY PRIMARY KEY, EmployeeId int NOT NULL, WorkDate date NOT NULL, RequestedStart varchar(30) NULL, RequestedEnd varchar(30) NULL,
 MissingMinutes int NOT NULL, Reason nvarchar(1000) NOT NULL, Status nvarchar(30) NOT NULL DEFAULT 'Pendiente',
 ReviewedById int NULL, ReviewNotes nvarchar(1000) NULL, CreatedAtUtc datetime2 NOT NULL, ReviewedAtUtc datetime2 NULL
);
CREATE TABLE dbo.AuditEntries (
 Id bigint IDENTITY PRIMARY KEY, Actor nvarchar(80) NOT NULL, Action nvarchar(100) NOT NULL, Detail nvarchar(1000) NOT NULL, AtUtc datetime2 NOT NULL
);
GO
