using System.ComponentModel.DataAnnotations;

namespace WorkPulse.Api;

public static class Roles
{
    public const string Admin = "ADMIN";
    public const string Management = "GERENCIA";
    public const string Manager = "JEFE";
    public const string Employee = "EMPLEADO";
}

public class AppUser
{
    public int Id { get; set; }
    [MaxLength(80)] public string Username { get; set; } = "";
    [MaxLength(200)] public string PasswordHash { get; set; } = "";
    [MaxLength(100)] public string FirstName { get; set; } = "";
    [MaxLength(100)] public string LastName { get; set; } = "";
    [MaxLength(200)] public string Email { get; set; } = "";
    [MaxLength(100)] public string Department { get; set; } = "";
    [MaxLength(100)] public string Position { get; set; } = "";
    public int? ManagerId { get; set; }
    [MaxLength(30)] public string Role { get; set; } = Roles.Employee;
    [MaxLength(30)] public string EmploymentStatus { get; set; } = "Activo";
    public TimeSpan ScheduleStart { get; set; } = new(8,0,0);
    public TimeSpan ScheduleEnd { get; set; } = new(17,0,0);
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
}

public class Device
{
    public int Id { get; set; }
    [MaxLength(100)] public string DeviceName { get; set; } = "";
    [MaxLength(200)] public string DeviceTokenHash { get; set; } = "";
    public int? EmployeeId { get; set; }
    [MaxLength(200)] public string OperatingSystem { get; set; } = "";
    public DateTime? LastSeenUtc { get; set; }
    public bool IsEnabled { get; set; } = true;
}

public class AgentEvent
{
    public long Id { get; set; }
    public int DeviceId { get; set; }
    public Device? Device { get; set; }
    public DateTime EventAtUtc { get; set; } = DateTime.UtcNow;
    [MaxLength(200)] public string WindowsUser { get; set; } = "";
    [MaxLength(100)] public string MachineName { get; set; } = "";
    [MaxLength(200)] public string OperatingSystem { get; set; } = "";
    [MaxLength(200)] public string ProcessName { get; set; } = "";
    public bool IsIdle { get; set; }
}

public class TimeRequest
{
    public int Id { get; set; }
    public int EmployeeId { get; set; }
    public DateOnly WorkDate { get; set; }
    public TimeSpan? RequestedStart { get; set; }
    public TimeSpan? RequestedEnd { get; set; }
    public int MissingMinutes { get; set; }
    [MaxLength(1000)] public string Reason { get; set; } = "";
    [MaxLength(30)] public string Status { get; set; } = "Pendiente";
    public int? ReviewedById { get; set; }
    [MaxLength(1000)] public string? ReviewNotes { get; set; }
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
    public DateTime? ReviewedAtUtc { get; set; }
}

public class AuditEntry
{
    public long Id { get; set; }
    [MaxLength(80)] public string Actor { get; set; } = "";
    [MaxLength(100)] public string Action { get; set; } = "";
    [MaxLength(1000)] public string Detail { get; set; } = "";
    public DateTime AtUtc { get; set; } = DateTime.UtcNow;
}

public record LoginDto(string Username, string Password);
public record FirstAdminDto(string Username, string Password, string FirstName, string LastName, string Email);
public record CreateDeviceDto(string DeviceName, int? EmployeeId, string OperatingSystem);
public record CreateUserDto(string Username, string Password, string FirstName, string LastName, string Email, string Department, string Position, int? ManagerId, string Role, string EmploymentStatus, string ScheduleStart, string ScheduleEnd);
public record ResetPasswordDto(string NewPassword);
public record CreateTimeRequestDto(DateOnly WorkDate, string? RequestedStart, string? RequestedEnd, int MissingMinutes, string Reason);
public record DecisionDto(string Decision, string? Notes);
public record HeartbeatDto(string MachineName, string WindowsUser, string OperatingSystem, string ProcessName, bool IsIdle);
