using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<AppDbContext>(o => o.UseSqlServer(builder.Configuration.GetConnectionString("WorkPulse")));
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
var signingKey = builder.Configuration["Jwt:SigningKey"] ?? throw new InvalidOperationException("Falta Jwt:SigningKey");
if (signingKey.Length < 48 || signingKey.StartsWith("REEMPLAZA", StringComparison.OrdinalIgnoreCase))
    throw new InvalidOperationException("Configura Jwt:SigningKey con un secreto aleatorio largo antes de ejecutar.");
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(o =>
{
    o.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true, ValidIssuer = builder.Configuration["Jwt:Issuer"],
        ValidateAudience = true, ValidAudience = builder.Configuration["Jwt:Audience"],
        ValidateIssuerSigningKey = true, IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(signingKey)),
        ValidateLifetime = true, ClockSkew = TimeSpan.FromSeconds(30)
    };
});
builder.Services.AddAuthorization();
builder.Services.AddCors(o => o.AddDefaultPolicy(p => p.WithOrigins("http://localhost:5080", "https://localhost:7080").AllowAnyHeader().AllowAnyMethod()));
var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    await db.Database.EnsureCreatedAsync(); // Solo crea un esquema inicial; usar migraciones versionadas en producción.
}

if (app.Environment.IsDevelopment()) { app.UseSwagger(); app.UseSwaggerUI(); }
app.UseDefaultFiles();
app.UseStaticFiles();
app.UseCors();
app.UseAuthentication();
app.UseAuthorization();

string Token(AppUser u)
{
    var claims = new[] {
        new Claim(ClaimTypes.NameIdentifier, u.Id.ToString()),
        new Claim(ClaimTypes.Name, u.Username),
        new Claim(ClaimTypes.Role, u.Role),
        new Claim("department", u.Department ?? "")
    };
    var creds = new SigningCredentials(new SymmetricSecurityKey(Encoding.UTF8.GetBytes(signingKey)), SecurityAlgorithms.HmacSha256);
    var token = new JwtSecurityToken(builder.Configuration["Jwt:Issuer"], builder.Configuration["Jwt:Audience"], claims,
        expires: DateTime.UtcNow.AddHours(8), signingCredentials: creds);
    return new JwtSecurityTokenHandler().WriteToken(token);
}
int UserId(ClaimsPrincipal p) => int.Parse(p.FindFirstValue(ClaimTypes.NameIdentifier)!);
bool IsManagerOf(AppDbContext db, int managerId, int employeeId, AppUser manager)
{
    var employee = db.Users.AsNoTracking().FirstOrDefault(x => x.Id == employeeId);
    return employee != null && (employee.ManagerId == managerId ||
        (manager.Role == Roles.Management && employee.Department == manager.Department));
}
void Audit(AppDbContext db, string actor, string action, string detail)
{
    db.AuditEntries.Add(new AuditEntry { Actor = actor, Action = action, Detail = detail, AtUtc = DateTime.UtcNow });
}

app.MapGet("/", () => Results.Redirect("/index.html"));
app.MapPost("/api/setup/first-admin", async (HttpRequest req, FirstAdminDto dto, AppDbContext db, IConfiguration cfg) =>
{
    var supplied = req.Headers["X-Setup-Secret"].ToString();
    var expected = cfg["Bootstrap:SetupSecret"] ?? "";
    if (expected.Length < 20 || expected.StartsWith("REEMPLAZA", StringComparison.OrdinalIgnoreCase))
        return Results.Problem("Configura Bootstrap:SetupSecret en appsettings.json antes de inicializar.", statusCode: 503);
    if (!CryptographicOperations.FixedTimeEquals(Encoding.UTF8.GetBytes(supplied), Encoding.UTF8.GetBytes(expected)))
        return Results.Unauthorized();
    if (await db.Users.AnyAsync()) return Results.Conflict(new { message = "Ya existe al menos un usuario; el bootstrap está cerrado." });
    if (dto.Password.Length < 12) return Results.BadRequest(new { message = "La contraseña inicial debe tener al menos 12 caracteres." });
    var u = new AppUser { Username = dto.Username.Trim(), PasswordHash = BCrypt.Net.BCrypt.HashPassword(dto.Password), FirstName = dto.FirstName.Trim(), LastName = dto.LastName.Trim(), Email = dto.Email.Trim(), Role = Roles.Admin, EmploymentStatus = "Activo" };
    db.Users.Add(u); Audit(db, u.Username, "FIRST_ADMIN_CREATED", "Primer administrador creado"); await db.SaveChangesAsync();
    return Results.Ok(new { token = Token(u), username = u.Username, role = u.Role });
});

app.MapPost("/api/auth/login", async (LoginDto dto, AppDbContext db) =>
{
    var u = await db.Users.FirstOrDefaultAsync(x => x.Username == dto.Username && x.EmploymentStatus == "Activo");
    if (u == null || !BCrypt.Net.BCrypt.Verify(dto.Password, u.PasswordHash)) return Results.Unauthorized();
    return Results.Ok(new { token = Token(u), username = u.Username, name = u.FirstName + " " + u.LastName, role = u.Role, department = u.Department });
});

app.MapGet("/api/me", (ClaimsPrincipal p, AppDbContext db) =>
{
    var u = db.Users.AsNoTracking().FirstOrDefault(x => x.Id == UserId(p));
    if (u == null) return (IResult)Results.NotFound();
    return Results.Ok(new { u.Id, u.Username, u.FirstName, u.LastName, u.Email, u.Department, u.Position, u.Role, u.EmploymentStatus, u.ScheduleStart, u.ScheduleEnd });
}).RequireAuthorization();

app.MapGet("/api/dashboard/me", async (ClaimsPrincipal p, AppDbContext db, DateOnly? date) =>
{
    int uid = UserId(p); var day = date ?? DateOnly.FromDateTime(DateTime.Today);
    var user = await db.Users.AsNoTracking().FirstOrDefaultAsync(x => x.Id == uid);
    if (user == null) return Results.NotFound();
    var from = day.ToDateTime(TimeOnly.MinValue).ToUniversalTime(); var to = from.AddDays(1);
    var events = await db.AgentEvents.Include(e => e.Device).Where(e => e.Device!.EmployeeId == uid && e.EventAtUtc >= from && e.EventAtUtc < to).OrderBy(e => e.EventAtUtc).ToListAsync();
    var active = events.Count(e => !e.IsIdle);
    var idle = events.Count(e => e.IsIdle);
    var reqs = await db.TimeRequests.Where(x => x.EmployeeId == uid && x.WorkDate == day).OrderByDescending(x => x.CreatedAtUtc).ToListAsync();
    var first = events.FirstOrDefault(); var last = events.LastOrDefault();
    var lateMinutes = first == null ? 0 : Math.Max(0, (int)(first.EventAtUtc.ToLocalTime().TimeOfDay - user.ScheduleStart).TotalMinutes);
    return Results.Ok(new { date = day, firstSeen = first?.EventAtUtc, lastSeen = last?.EventAtUtc, activeSamples = active, idleSamples = idle, lateMinutes, requests = reqs });
}).RequireAuthorization();

app.MapGet("/api/dashboard/management", async (ClaimsPrincipal p, AppDbContext db, DateOnly? date) =>
{
    var role = p.FindFirstValue(ClaimTypes.Role);
    if (role is not (Roles.Admin or Roles.Management or Roles.Manager)) return Results.Forbid();
    var day = date ?? DateOnly.FromDateTime(DateTime.Today);
    var current = await db.Users.AsNoTracking().Where(x => x.EmploymentStatus == "Activo" &&
        (role != Roles.Management || x.Department == p.FindFirstValue("department"))).ToListAsync();
    var rows = new List<object>();
    foreach (var u in current)
    {
        var d = await db.Devices.Where(x => x.EmployeeId == u.Id).Select(x => (int?)x.Id).ToListAsync();
        var start = day.ToDateTime(TimeOnly.MinValue).ToUniversalTime(); var end = start.AddDays(1);
        var ev = await db.AgentEvents.Where(x => d.Contains(x.DeviceId) && x.EventAtUtc >= start && x.EventAtUtc < end).OrderBy(x => x.EventAtUtc).ToListAsync();
        var first = ev.FirstOrDefault();
        rows.Add(new { employeeId = u.Id, name = u.FirstName + " " + u.LastName, department = u.Department, role = u.Role,
            firstSeen = first?.EventAtUtc, samples = ev.Count, lateMinutes = first == null ? (int?)null : Math.Max(0,(int)(first.EventAtUtc.ToLocalTime().TimeOfDay-u.ScheduleStart).TotalMinutes) });
    }
    return Results.Ok(new { date = day, employees = rows });
}).RequireAuthorization();

app.MapGet("/api/users", async (ClaimsPrincipal p, AppDbContext db) =>
{
    var role = p.FindFirstValue(ClaimTypes.Role);
    if (role is not (Roles.Admin or Roles.Management or Roles.Manager)) return Results.Forbid();
    var q = db.Users.AsNoTracking().Where(x => x.EmploymentStatus != "Eliminado");
    if (role == Roles.Management) q = q.Where(x => x.Department == p.FindFirstValue("department"));
    if (role == Roles.Manager) q = q.Where(x => x.ManagerId == UserId(p) || x.Id == UserId(p));
    return Results.Ok(await q.OrderBy(x => x.LastName).Select(x => new { x.Id, x.Username, x.FirstName, x.LastName, x.Email, x.Department, x.Position, x.ManagerId, x.Role, x.EmploymentStatus, x.ScheduleStart, x.ScheduleEnd }).ToListAsync());
}).RequireAuthorization();

app.MapPost("/api/users", async (ClaimsPrincipal p, CreateUserDto dto, AppDbContext db) =>
{
    if (p.FindFirstValue(ClaimTypes.Role) != Roles.Admin) return Results.Forbid();
    if (dto.Password.Length < 12) return Results.BadRequest(new { message = "La contraseña debe tener al menos 12 caracteres." });
    if (await db.Users.AnyAsync(x => x.Username == dto.Username.Trim())) return Results.Conflict(new { message = "El usuario ya existe." });
    if (!TimeSpan.TryParse(dto.ScheduleStart, out var start) || !TimeSpan.TryParse(dto.ScheduleEnd, out var end)) return Results.BadRequest(new { message = "Horario inválido. Usa HH:mm." });
    if (dto.Role is not (Roles.Admin or Roles.Management or Roles.Manager or Roles.Employee)) return Results.BadRequest(new { message = "Rol inválido." });
    var u = new AppUser { Username = dto.Username.Trim(), PasswordHash = BCrypt.Net.BCrypt.HashPassword(dto.Password), FirstName = dto.FirstName.Trim(), LastName = dto.LastName.Trim(), Email = dto.Email.Trim(), Department = dto.Department.Trim(), Position = dto.Position.Trim(), ManagerId = dto.ManagerId, Role = dto.Role, EmploymentStatus = dto.EmploymentStatus, ScheduleStart = start, ScheduleEnd = end };
    db.Users.Add(u); Audit(db, p.Identity?.Name ?? "?", "USER_CREATED", u.Username); await db.SaveChangesAsync();
    return Results.Created($"/api/users/{u.Id}", new { u.Id, u.Username });
}).RequireAuthorization();

app.MapPost("/api/users/{id:int}/reset-password", async (int id, ResetPasswordDto dto, ClaimsPrincipal p, AppDbContext db) =>
{
    if (p.FindFirstValue(ClaimTypes.Role) != Roles.Admin) return Results.Forbid();
    if (dto.NewPassword.Length < 12) return Results.BadRequest(new { message = "La nueva contraseña debe tener al menos 12 caracteres." });
    var u = await db.Users.FindAsync(id); if (u == null) return Results.NotFound();
    u.PasswordHash = BCrypt.Net.BCrypt.HashPassword(dto.NewPassword);
    Audit(db, p.Identity?.Name ?? "?", "PASSWORD_RESET", u.Username); await db.SaveChangesAsync();
    return Results.NoContent();
}).RequireAuthorization();

app.MapGet("/api/time-requests", async (ClaimsPrincipal p, AppDbContext db) =>
{
    int uid = UserId(p); var role = p.FindFirstValue(ClaimTypes.Role);
    var q = db.TimeRequests.AsNoTracking();
    if (role == Roles.Employee) q = q.Where(x => x.EmployeeId == uid);
    else if (role == Roles.Manager) q = q.Where(x => x.EmployeeId == uid || db.Users.Any(u => u.Id == x.EmployeeId && u.ManagerId == uid));
    else if (role == Roles.Management) q = q.Where(x => db.Users.Any(u => u.Id == x.EmployeeId && u.Department == p.FindFirstValue("department")));
    return Results.Ok(await q.OrderByDescending(x => x.CreatedAtUtc).ToListAsync());
}).RequireAuthorization();

app.MapPost("/api/time-requests", async (CreateTimeRequestDto dto, ClaimsPrincipal p, AppDbContext db) =>
{
    if (dto.MissingMinutes < 1 || dto.MissingMinutes > 1440 || string.IsNullOrWhiteSpace(dto.Reason)) return Results.BadRequest(new { message = "Indica minutos faltantes y motivo." });
    TimeSpan? start = null, end = null;
    if (dto.RequestedStart != null && !TimeSpan.TryParse(dto.RequestedStart, out var s)) return Results.BadRequest(new { message = "Hora de entrada inválida." }); else if (dto.RequestedStart != null) start = TimeSpan.Parse(dto.RequestedStart);
    if (dto.RequestedEnd != null && !TimeSpan.TryParse(dto.RequestedEnd, out var e)) return Results.BadRequest(new { message = "Hora de salida inválida." }); else if (dto.RequestedEnd != null) end = TimeSpan.Parse(dto.RequestedEnd);
    var r = new TimeRequest { EmployeeId = UserId(p), WorkDate = dto.WorkDate, RequestedStart = start, RequestedEnd = end, MissingMinutes = dto.MissingMinutes, Reason = dto.Reason.Trim() };
    db.TimeRequests.Add(r); Audit(db, p.Identity?.Name ?? "?", "TIME_REQUEST_CREATED", $"{dto.WorkDate}: {dto.MissingMinutes} minutos"); await db.SaveChangesAsync();
    return Results.Created($"/api/time-requests/{r.Id}", r);
}).RequireAuthorization();

app.MapPost("/api/time-requests/{id:int}/decision", async (int id, DecisionDto dto, ClaimsPrincipal p, AppDbContext db) =>
{
    if (p.FindFirstValue(ClaimTypes.Role) is not (Roles.Admin or Roles.Management or Roles.Manager)) return Results.Forbid();
    var r = await db.TimeRequests.FindAsync(id); if (r == null) return Results.NotFound();
    if (r.Status != "Pendiente") return Results.Conflict(new { message = "La solicitud ya fue resuelta." });
    var employee = await db.Users.FindAsync(r.EmployeeId); if (employee == null) return Results.NotFound();
    if (p.FindFirstValue(ClaimTypes.Role) == Roles.Manager && employee.ManagerId != UserId(p)) return Results.Forbid();
    if (p.FindFirstValue(ClaimTypes.Role) == Roles.Management && employee.Department != p.FindFirstValue("department")) return Results.Forbid();
    if (dto.Decision is not ("Aprobada" or "Rechazada")) return Results.BadRequest(new { message = "Decisión inválida." });
    r.Status = dto.Decision; r.ReviewedById = UserId(p); r.ReviewNotes = dto.Notes; r.ReviewedAtUtc = DateTime.UtcNow;
    Audit(db, p.Identity?.Name ?? "?", "TIME_REQUEST_" + dto.Decision.ToUpperInvariant(), $"Solicitud {id}; empleado {employee.Username}; {dto.Notes}");
    await db.SaveChangesAsync(); return Results.Ok(r);
}).RequireAuthorization();


app.MapGet("/api/devices", async (ClaimsPrincipal p, AppDbContext db) =>
{
    var role = p.FindFirstValue(ClaimTypes.Role);
    if (role is not (Roles.Admin or Roles.Management or Roles.Manager)) return Results.Forbid();
    var q = db.Devices.AsNoTracking();
    if (role == Roles.Management) q = q.Where(d => d.EmployeeId != null && db.Users.Any(u => u.Id == d.EmployeeId && u.Department == p.FindFirstValue("department")));
    if (role == Roles.Manager) q = q.Where(d => d.EmployeeId == UserId(p) || db.Users.Any(u => u.Id == d.EmployeeId && u.ManagerId == UserId(p)));
    return Results.Ok(await q.Select(d => new {
        d.Id, d.DeviceName, d.EmployeeId, employeeName = db.Users.Where(u => u.Id == d.EmployeeId).Select(u => u.FirstName + " " + u.LastName).FirstOrDefault(),
        d.OperatingSystem, d.LastSeenUtc, d.IsEnabled
    }).ToListAsync());
}).RequireAuthorization();

app.MapPost("/api/devices", async (CreateDeviceDto dto, ClaimsPrincipal p, AppDbContext db) =>
{
    if (p.FindFirstValue(ClaimTypes.Role) != Roles.Admin) return Results.Forbid();
    if (string.IsNullOrWhiteSpace(dto.DeviceName)) return Results.BadRequest(new { message = "Indica el nombre del equipo." });
    if (dto.EmployeeId.HasValue && !await db.Users.AnyAsync(u => u.Id == dto.EmployeeId.Value && u.EmploymentStatus == "Activo"))
        return Results.BadRequest(new { message = "El empleado asignado no existe o está inactivo." });
    var raw = Convert.ToBase64String(RandomNumberGenerator.GetBytes(32)).TrimEnd('=').Replace('+','-').Replace('/','_');
    var hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(raw)));
    var device = new Device { DeviceName = dto.DeviceName.Trim(), DeviceTokenHash = hash, EmployeeId = dto.EmployeeId, OperatingSystem = dto.OperatingSystem ?? "", IsEnabled = true };
    db.Devices.Add(device); Audit(db, p.Identity?.Name ?? "?", "DEVICE_CREATED", device.DeviceName); await db.SaveChangesAsync();
    return Results.Ok(new { device.Id, device.DeviceName, deviceToken = raw });
}).RequireAuthorization();

app.MapPost("/api/agent/heartbeat", async (HttpRequest req, HeartbeatDto dto, AppDbContext db) =>
{
    var token = req.Headers["X-Device-Token"].ToString();
    if (string.IsNullOrWhiteSpace(token)) return Results.Unauthorized();
    var tokenHash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(token)));
    var device = await db.Devices.FirstOrDefaultAsync(x => x.DeviceTokenHash == tokenHash && x.IsEnabled);
    if (device == null) return Results.Unauthorized();
    device.LastSeenUtc = DateTime.UtcNow;
    db.AgentEvents.Add(new AgentEvent { DeviceId = device.Id, MachineName = dto.MachineName, WindowsUser = dto.WindowsUser, OperatingSystem = dto.OperatingSystem, ProcessName = dto.ProcessName, IsIdle = dto.IsIdle, EventAtUtc = DateTime.UtcNow });
    await db.SaveChangesAsync(); return Results.Ok(new { received = true, utc = DateTime.UtcNow });
}).AllowAnonymous();

app.MapGet("/api/reports/attendance.xlsx", async (DateOnly from, DateOnly to, ClaimsPrincipal p, AppDbContext db) =>
{
    var role = p.FindFirstValue(ClaimTypes.Role);
    if (role is not (Roles.Admin or Roles.Management or Roles.Manager)) return Results.Forbid();
    if (to < from || to.DayNumber - from.DayNumber > 366) return Results.BadRequest(new { message = "Rango inválido (máximo 366 días)." });
    var users = await db.Users.AsNoTracking().Where(x => x.EmploymentStatus != "Eliminado").ToListAsync();
    if (role == Roles.Management) users = users.Where(x => x.Department == p.FindFirstValue("department")).ToList();
    if (role == Roles.Manager) users = users.Where(x => x.ManagerId == UserId(p) || x.Id == UserId(p)).ToList();
    var ids = users.Select(x => x.Id).ToHashSet();
    var devices = await db.Devices.AsNoTracking().Where(x => x.EmployeeId != null && ids.Contains(x.EmployeeId.Value)).ToListAsync();
    var devIds = devices.Select(x => x.Id).ToList();
    var startUtc = from.ToDateTime(TimeOnly.MinValue).ToUniversalTime();
    var endUtc = to.AddDays(1).ToDateTime(TimeOnly.MinValue).ToUniversalTime();
    var events = await db.AgentEvents.AsNoTracking().Where(x => devIds.Contains(x.DeviceId) && x.EventAtUtc >= startUtc && x.EventAtUtc < endUtc).OrderBy(x => x.EventAtUtc).ToListAsync();
    using var wb = new XLWorkbook(); var ws = wb.Worksheets.Add("Asistencia");
    string[] headers = { "Empleado", "Usuario", "Gerencia", "Fecha", "Primera actividad", "Última actividad", "Horario esperado", "Entrada tardía (min)", "Última actividad posterior al horario (min)", "Muestras activas", "Muestras inactivas", "Equipo(s)" };
    for (int i=0;i<headers.Length;i++) ws.Cell(1,i+1).Value=headers[i];
    int row=2;
    foreach(var u in users)
    {
        for(var d=from; d<=to; d=d.AddDays(1))
        {
            var devs=devices.Where(x=>x.EmployeeId==u.Id).ToList(); var idsForUser=devs.Select(x=>x.Id).ToHashSet();
            var dayEvents=events.Where(x=>idsForUser.Contains(x.DeviceId) && DateOnly.FromDateTime(x.EventAtUtc.ToLocalTime())==d).OrderBy(x=>x.EventAtUtc).ToList();
            var first=dayEvents.FirstOrDefault(); var last=dayEvents.LastOrDefault();
            ws.Cell(row,1).Value=u.FirstName+" "+u.LastName; ws.Cell(row,2).Value=u.Username; ws.Cell(row,3).Value=u.Department;
            ws.Cell(row,4).Value=d.ToDateTime(TimeOnly.MinValue); ws.Cell(row,4).Style.DateFormat.Format="dd/MM/yyyy";
            if(first!=null){ws.Cell(row,5).Value=first.EventAtUtc.ToLocalTime().DateTime;ws.Cell(row,5).Style.DateFormat.Format="HH:mm:ss";}
            if(last!=null){ws.Cell(row,6).Value=last.EventAtUtc.ToLocalTime().DateTime;ws.Cell(row,6).Style.DateFormat.Format="HH:mm:ss";}
            ws.Cell(row,7).Value=u.ScheduleStart.ToString(@"hh\:mm")+" - "+u.ScheduleEnd.ToString(@"hh\:mm");
            ws.Cell(row,8).Value=first==null ? "" : Math.Max(0,(int)(first.EventAtUtc.ToLocalTime().TimeOfDay-u.ScheduleStart).TotalMinutes);
            ws.Cell(row,9).Value=last==null ? "" : Math.Max(0,(int)(last.EventAtUtc.ToLocalTime().TimeOfDay-u.ScheduleEnd).TotalMinutes);
            ws.Cell(row,10).Value=dayEvents.Count(x=>!x.IsIdle); ws.Cell(row,11).Value=dayEvents.Count(x=>x.IsIdle);
            ws.Cell(row,12).Value=string.Join(", ",devs.Select(x=>x.DeviceName)); row++;
        }
    }
    ws.Row(1).Style.Font.Bold=true; ws.Row(1).Style.Fill.BackgroundColor=XLColor.LightBlue; ws.SheetView.FreezeRows(1); ws.Columns().AdjustToContents();
    using var ms=new MemoryStream(); wb.SaveAs(ms);
    return Results.File(ms.ToArray(),"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",$"WorkPulse_Asistencia_{from}_{to}.xlsx");
}).RequireAuthorization();

app.MapFallbackToFile("index.html");
app.Run();
