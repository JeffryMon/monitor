using Microsoft.EntityFrameworkCore;

namespace WorkPulse.Api;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<AppUser> Users => Set<AppUser>();
    public DbSet<Device> Devices => Set<Device>();
    public DbSet<AgentEvent> AgentEvents => Set<AgentEvent>();
    public DbSet<TimeRequest> TimeRequests => Set<TimeRequest>();
    public DbSet<AuditEntry> AuditEntries => Set<AuditEntry>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<AppUser>().HasIndex(x => x.Username).IsUnique();
        b.Entity<Device>().HasIndex(x => x.DeviceName);
        b.Entity<AgentEvent>().HasIndex(x => new { x.DeviceId, x.EventAtUtc });
        b.Entity<TimeRequest>().HasIndex(x => new { x.EmployeeId, x.WorkDate });
        b.Entity<AppUser>().Property(x => x.ScheduleStart).HasConversion(
            v => v.ToString("c"), v => TimeSpan.Parse(v));
        b.Entity<AppUser>().Property(x => x.ScheduleEnd).HasConversion(
            v => v.ToString("c"), v => TimeSpan.Parse(v));
        b.Entity<TimeRequest>().Property(x => x.WorkDate).HasConversion(
            v => v.ToDateTime(TimeOnly.MinValue), v => DateOnly.FromDateTime(v));
        b.Entity<TimeRequest>().Property(x => x.RequestedStart).HasConversion(
            v => v.HasValue ? v.Value.ToString("c") : null,
            v => string.IsNullOrWhiteSpace(v) ? null : TimeSpan.Parse(v));
        b.Entity<TimeRequest>().Property(x => x.RequestedEnd).HasConversion(
            v => v.HasValue ? v.Value.ToString("c") : null,
            v => string.IsNullOrWhiteSpace(v) ? null : TimeSpan.Parse(v));
    }
}
