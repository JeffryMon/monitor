using Microsoft.AspNetCore.Mvc; using SQLServerManager.Api.Models; using SQLServerManager.Api.Services;
namespace SQLServerManager.Api.Controllers;
[ApiController][Route("api/servers")]
public class ServersController:ControllerBase{readonly CentralRepository r;readonly SqlServerService s;readonly AuditService a;public ServersController(CentralRepository r,SqlServerService s,AuditService a){this.r=r;this.s=s;this.a=a;}
[HttpGet] public async Task<IActionResult> List()=>Ok(await r.Servers());
[HttpPost] public async Task<IActionResult> Add(CreateServerRequest x){var id=await r.AddServer(x);var v=await r.Server(id);if(v is not null){try{var m=await s.ServerMetadata(v);await r.UpdateMetadata(id,m.Version,m.Edition,m.OperatingSystem);}catch{}}return Ok(new{id});}
[HttpPut("{id:int}")] public async Task<IActionResult> Update(int id,CreateServerRequest x){if(await r.Server(id) is null)return NotFound();await r.UpdateServer(id,x);var v=await r.Server(id);if(v is not null){try{var m=await s.ServerMetadata(v);await r.UpdateMetadata(id,m.Version,m.Edition,m.OperatingSystem);}catch{}}return Ok();}
[HttpPost("{id:int}/active")] public async Task<IActionResult> Active(int id,[FromBody]bool active){if(await r.Server(id) is null)return NotFound();await r.SetActive(id,active);return Ok();}
[HttpPost("{id:int}/test")] public async Task<IActionResult> Test(int id){var v=await r.Server(id);return v is null?NotFound():Ok(await s.Test(v));}
[HttpPost("{id:int}/dashboard")] public async Task<IActionResult> Dashboard(int id){var v=await r.Server(id);if(v is null)return NotFound();try{return Ok(await s.Dashboard(v));}catch(Exception e){return BadRequest(new{error=e.Message});}}
[HttpGet("{id:int}/logins")] public async Task<IActionResult> Logins(int id,[FromQuery]string? search=null){var v=await r.Server(id);if(v is null)return NotFound();return Ok(await s.Logins(v,search));}
[HttpPost("{id:int}/logins/{login}/disable")] public async Task<IActionResult> DisableLogin(int id,string login){return await ChangeLogin(id,login,true);}
[HttpPost("{id:int}/logins/{login}/enable")] public async Task<IActionResult> EnableLogin(int id,string login){return await ChangeLogin(id,login,false);}
async Task<IActionResult> ChangeLogin(int id,string login,bool disabled){var v=await r.Server(id);if(v is null)return NotFound();try{await s.SetLoginDisabled(v,login,disabled);await a.Ok(id,disabled?"DISABLE_LOGIN":"ENABLE_LOGIN",login);return Ok();}catch(Exception e){await a.Error(id,disabled?"DISABLE_LOGIN":"ENABLE_LOGIN",login,e);return BadRequest(new{error=e.Message});}}
[HttpPost("{id:int}/roles")] public async Task<IActionResult> Roles(int id){var v=await r.Server(id);if(v is null)return NotFound();return Ok(await s.Roles(v));}
[HttpGet("{id:int}/databases")] public async Task<IActionResult> Databases(int id,[FromQuery]string? search=null){var v=await r.Server(id);if(v is null)return NotFound();return Ok(await s.Databases(v,search));}
[HttpPost("{id:int}/sessions")] public async Task<IActionResult> Sessions(int id){var v=await r.Server(id);if(v is null)return NotFound();return Ok(await s.Sessions(v));}
[HttpPost("{id:int}/sessions/{spid:int}/kill")] public async Task<IActionResult> Kill(int id,int spid){var v=await r.Server(id);if(v is null)return NotFound();try{await s.Kill(v,spid);await a.Ok(id,"KILL_SESSION",spid.ToString());return Ok();}catch(Exception e){await a.Error(id,"KILL_SESSION",spid.ToString(),e);return BadRequest(new{error=e.Message});}}
[HttpGet("{id:int}/audits")] public async Task<IActionResult> Audits(int id){var v=await r.Server(id);if(v is null)return NotFound();try{return Ok(await s.Audits(v));}catch(Exception e){return BadRequest(new{error=e.Message});}}
[HttpGet("{id:int}/audit-specifications")] public async Task<IActionResult> AuditSpecifications(int id){var v=await r.Server(id);if(v is null)return NotFound();try{return Ok(await s.AuditSpecifications(v));}catch(Exception e){return BadRequest(new{error=e.Message});}}
[HttpGet("{id:int}/jobs")] public async Task<IActionResult> Jobs(int id){var v=await r.Server(id);if(v is null)return NotFound();try{return Ok(await s.Jobs(v));}catch(Exception e){return BadRequest(new{error=e.Message});}}
[HttpGet("{id:int}/audits/events")] public async Task<IActionResult> AuditEvents(int id,[FromQuery]string auditName,[FromQuery]int year,[FromQuery]int month,[FromQuery]int take=300){var v=await r.Server(id);if(v is null)return NotFound();try{return Ok(await s.AuditEvents(v,auditName,year,month,Math.Clamp(take,1,1000)));}catch(Exception e){return BadRequest(new{error=e.Message});}}
}
