# SQL Server Manager V6

Consola centralizada para monitorizar y administrar múltiples SQL Server mediante **Windows Authentication**, con autenticación propia de la aplicación almacenada en `SQL_ADMIN_CENTER`.

## Cambios V6
- Login de aplicación con cookie y cierre de sesión.
- Usuario inicial `admin` / `admin` (crear otro usuario ADMIN y desactivar el inicial antes de producción).
- Roles de aplicación: `ADMIN`, `DBA`, `MONITOR`.
- Gestión de usuarios, activación/desactivación y asignación de roles.
- Auditorías y timeline actualizan al cambiar de servidor.
- Al registrar/editar un servidor se consulta automáticamente `@@VERSION`, edición y sistema operativo; estos datos son de solo lectura en la UI.
- Comentarios por login, con historial y usuario/fecha.
- Alertas evaluadas también durante la monitorización en vivo, más reglas para BD online, tamaño total de BD y jobs fallidos.
- Eliminación de reglas de alerta junto con sus incidencias.
- Resumen de bases de datos con tamaño total en GB.
- Métricas históricas guardan tamaño total de BD y jobs fallidos.
- Archivos/documentación por servidor: ER, diccionario de datos, manuales, diagramas, etc.

## Requisitos
- .NET 8 SDK
- SQL Server para `SQL_ADMIN_CENTER`
- Cuenta Windows que ejecute la aplicación con permisos en los SQL Server administrados.
- Para métricas/auditorías puede requerirse `VIEW SERVER STATE` y los permisos específicos de SQL Server.

## Instalación
1. Ejecutar `database/01_create_database.sql` en el SQL Server central.
2. Revisar `src/SQLServerManager.Api/appsettings.json`.
3. Ejecutar `dotnet restore`.
4. Ejecutar `dotnet run`.
5. Abrir la interfaz web.
6. Entrar inicialmente con `admin` / `admin`. Crear el usuario definitivo con rol ADMIN y desactivar el usuario inicial.

## Roles
- **ADMIN**: acceso total y gestión de usuarios/roles.
- **DBA**: administración técnica; puede modificar servidores, logins, sesiones, archivos, timeline y alertas.
- **MONITOR**: consulta y monitorización sin operaciones destructivas.

La autenticación hacia los SQL Server administrados continúa siendo exclusivamente **Windows Authentication**. Las contraseñas de los logins SQL administrados no se almacenan en esta aplicación.
