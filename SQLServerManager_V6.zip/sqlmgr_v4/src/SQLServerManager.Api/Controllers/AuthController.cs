using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SQLServerManager.Api.Models;
using SQLServerManager.Api.Services;

namespace SQLServerManager.Api.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    readonly AuthService auth; readonly CentralRepository repo;
    public AuthController(AuthService auth, CentralRepository repo){this.auth=auth;this.repo=repo;}

    [AllowAnonymous, HttpPost("login")]
    public async Task<IActionResult> Login(LoginRequest x)
    {
        var user=await auth.ValidateAsync(x.Username,x.Password);
        if(user is null)return Unauthorized(new{error="Usuario o contraseña incorrectos."});
        await auth.SignInAsync(HttpContext,user);
        return Ok(new{username=user.Username,role=user.RoleName});
    }

    [HttpPost("logout")]
    public async Task<IActionResult> Logout(){await HttpContext.SignOutAsync();return Ok();}

    [AllowAnonymous, HttpGet("me")]
    public IActionResult Me()=>Ok(new{authenticated=User.Identity?.IsAuthenticated==true,username=User.Identity?.Name,role=User.Claims.FirstOrDefault(x=>x.Type==System.Security.Claims.ClaimTypes.Role)?.Value});
}
