using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SQLServerManager.Api.Models;
using SQLServerManager.Api.Services;

namespace SQLServerManager.Api.Controllers;

[ApiController, Route("api/app-users"), Authorize(Roles="ADMIN")]
public class AppUsersController : ControllerBase
{
    readonly CentralRepository repo;
    public AppUsersController(CentralRepository repo)=>this.repo=repo;
    [HttpGet] public async Task<IActionResult> List()=>Ok(await repo.AppUsers());
    [HttpGet("roles")] public async Task<IActionResult> Roles()=>Ok(await repo.AppRoles());
    [HttpPost] public async Task<IActionResult> Add(CreateAppUserRequest x){if(string.IsNullOrWhiteSpace(x.Username)||string.IsNullOrWhiteSpace(x.Password))return BadRequest(new{error="Usuario y contraseña son requeridos."});return Ok(new{id=await repo.AddAppUser(x)});}
    [HttpPut("{id:int}/active")] public async Task<IActionResult> Active(int id,[FromBody]bool active){await repo.SetAppUserActive(id,active);return Ok();}
    [HttpPut("{id:int}/role")] public async Task<IActionResult> Role(int id,[FromBody]SetAppUserRoleRequest x){await repo.SetAppUserRole(id,x.RoleId);return Ok();}
}
