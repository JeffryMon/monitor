using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.OpenApi.Models;
using SQLServerManager.Api.Services;

var b=WebApplication.CreateBuilder(args);
b.Services.AddControllers();
b.Services.AddEndpointsApiExplorer();
b.Services.AddSwaggerGen(c=>c.SwaggerDoc("v1",new OpenApiInfo{Title="SQL Server Manager API",Version="6.0"}));
b.Services.AddSingleton<CentralRepository>();
b.Services.AddSingleton<SqlServerService>();
b.Services.AddSingleton<AuditService>();
b.Services.AddSingleton<AuthService>();
b.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme).AddCookie(o=>{o.LoginPath="/";o.AccessDeniedPath="/";o.Cookie.Name="SQLServerManager.Auth";o.ExpireTimeSpan=TimeSpan.FromHours(8);o.SlidingExpiration=true;});
b.Services.AddAuthorization();
var app=b.Build();
using(var scope=app.Services.CreateScope())
{
    try{await scope.ServiceProvider.GetRequiredService<AuthService>().InitializeAsync();}
    catch(Exception ex){Console.WriteLine($"No se pudo inicializar el usuario admin: {ex.Message}");}
}
app.UseDefaultFiles();
app.UseStaticFiles();
app.UseSwagger();
app.UseSwaggerUI();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.Run();
