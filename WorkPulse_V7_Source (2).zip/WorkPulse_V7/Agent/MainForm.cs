using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace WorkPulse.Agent
{
    internal sealed class MainForm : Form
    {
        private readonly string logPath; private readonly Label status=new Label(); private readonly TextBox logs=new TextBox(); private readonly Func<Task> testSend;
        public MainForm(string path,Action send){logPath=path;testSend=send;Text="WorkPulse — agente";StartPosition=FormStartPosition.CenterScreen;Size=new Size(720,500);MinimumSize=new Size(620,420);Font=new Font("Segoe UI",9);
            var title=new Label{Text="WorkPulse",Font=new Font("Segoe UI",19,FontStyle.Bold),AutoSize=true,Location=new Point(22,18)};
            status.SetBounds(24,60,660,40);status.Text="Inicializando...";
            logs.Multiline=true;logs.ReadOnly=true;logs.ScrollBars=ScrollBars.Vertical;logs.SetBounds(24,112,660,290);
            var send=new Button{Text="Enviar latido de prueba",Location=new Point(24,414),Size=new Size(170,30)};send.Click+=async(s,e)=>testSend();
            Controls.AddRange(new Control[]{title,status,logs,send});RefreshStatus();
        }
        public void SetConnectionStatus(string s){if(IsDisposed)return;if(InvokeRequired){BeginInvoke(new Action(()=>SetConnectionStatus(s)));return;}status.Text="Estado del último envío: "+s;RefreshStatus();}
        public void RefreshStatus(){if(IsDisposed)return;var lines=File.Exists(logPath)?File.ReadAllLines(logPath):new string[0];logs.Text=string.Join(Environment.NewLine,lines.Reverse().Take(100).Reverse());}
    }
}
