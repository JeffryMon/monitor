/*
 WorkPulse V4 — SQL Server
 No depende de Active Directory para usuarios/empleados.
 Ejecutar en una base WorkPulse existente o crearla antes.
*/
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

IF OBJECT_ID('dbo.Gerencia','U') IS NULL
CREATE TABLE dbo.Gerencia(
    GerenciaId INT IDENTITY(1,1) PRIMARY KEY,
    Nombre NVARCHAR(120) NOT NULL UNIQUE,
    Descripcion NVARCHAR(500) NULL,
    Estado BIT NOT NULL CONSTRAINT DF_Gerencia_Estado DEFAULT(1),
    FechaCreacion DATETIME2 NOT NULL CONSTRAINT DF_Gerencia_Fecha DEFAULT(SYSDATETIME())
);
GO

IF OBJECT_ID('dbo.Puesto','U') IS NULL
CREATE TABLE dbo.Puesto(
    PuestoId INT IDENTITY(1,1) PRIMARY KEY,
    Nombre NVARCHAR(120) NOT NULL UNIQUE,
    Descripcion NVARCHAR(500) NULL,
    Estado BIT NOT NULL CONSTRAINT DF_Puesto_Estado DEFAULT(1)
);
GO

IF OBJECT_ID('dbo.Usuario','U') IS NULL
CREATE TABLE dbo.Usuario(
    UsuarioId INT IDENTITY(1,1) PRIMARY KEY,
    NombreUsuario NVARCHAR(80) NOT NULL UNIQUE,
    PasswordHash NVARCHAR(500) NOT NULL,
    Nombre NVARCHAR(100) NOT NULL,
    Apellido NVARCHAR(100) NOT NULL,
    Correo NVARCHAR(254) NULL,
    Telefono NVARCHAR(40) NULL,
    Rol NVARCHAR(20) NOT NULL,
    Estado BIT NOT NULL CONSTRAINT DF_Usuario_Estado DEFAULT(1),
    DebeCambiarClave BIT NOT NULL CONSTRAINT DF_Usuario_Cambiar DEFAULT(1),
    UltimoAcceso DATETIME2 NULL,
    FechaCreacion DATETIME2 NOT NULL CONSTRAINT DF_Usuario_Fecha DEFAULT(SYSDATETIME()),
    CreadoPor INT NULL,
    CONSTRAINT CK_Usuario_Rol CHECK (Rol IN ('ADMIN','GERENCIA','JEFE','EMPLEADO')),
    CONSTRAINT FK_Usuario_Creador FOREIGN KEY(CreadoPor) REFERENCES dbo.Usuario(UsuarioId)
);
GO

IF OBJECT_ID('dbo.Empleado','U') IS NULL
CREATE TABLE dbo.Empleado(
    EmpleadoId INT IDENTITY(1,1) PRIMARY KEY,
    UsuarioId INT NOT NULL UNIQUE,
    CodigoEmpleado NVARCHAR(40) NULL UNIQUE,
    GerenciaId INT NULL,
    PuestoId INT NULL,
    JefeUsuarioId INT NULL,
    FechaIngreso DATE NULL,
    HorarioEntrada TIME(0) NULL,
    HorarioSalida TIME(0) NULL,
    ZonaHoraria NVARCHAR(80) NOT NULL CONSTRAINT DF_Empleado_Zona DEFAULT('Central America Standard Time'),
    Observaciones NVARCHAR(1000) NULL,
    EstadoLaboral NVARCHAR(20) NOT NULL CONSTRAINT DF_Empleado_Estado DEFAULT('ACTIVO'),
    FechaActualizacion DATETIME2 NOT NULL CONSTRAINT DF_Empleado_Actualizado DEFAULT(SYSDATETIME()),
    CONSTRAINT FK_Empleado_Usuario FOREIGN KEY(UsuarioId) REFERENCES dbo.Usuario(UsuarioId),
    CONSTRAINT FK_Empleado_Gerencia FOREIGN KEY(GerenciaId) REFERENCES dbo.Gerencia(GerenciaId),
    CONSTRAINT FK_Empleado_Puesto FOREIGN KEY(PuestoId) REFERENCES dbo.Puesto(PuestoId),
    CONSTRAINT FK_Empleado_Jefe FOREIGN KEY(JefeUsuarioId) REFERENCES dbo.Usuario(UsuarioId),
    CONSTRAINT CK_Empleado_Estado CHECK (EstadoLaboral IN ('ACTIVO','INACTIVO','LICENCIA','BAJA'))
);
GO

IF OBJECT_ID('dbo.Computadora','U') IS NULL
CREATE TABLE dbo.Computadora(
    ComputadoraId INT IDENTITY(1,1) PRIMARY KEY,
    EmpleadoId INT NULL,
    NombrePC NVARCHAR(150) NOT NULL,
    SistemaOperativo NVARCHAR(150) NULL,
    DireccionIP NVARCHAR(45) NULL,
    IdentificadorAgente NVARCHAR(120) NULL,
    TokenHash NVARCHAR(500) NULL,
    UltimoHeartbeat DATETIME2 NULL,
    VersionAgente NVARCHAR(40) NULL,
    Estado BIT NOT NULL CONSTRAINT DF_Computadora_Estado DEFAULT(1),
    FechaRegistro DATETIME2 NOT NULL CONSTRAINT DF_Computadora_Fecha DEFAULT(SYSDATETIME()),
    CONSTRAINT FK_Computadora_Empleado FOREIGN KEY(EmpleadoId) REFERENCES dbo.Empleado(EmpleadoId)
);
GO
CREATE INDEX IX_Computadora_Heartbeat ON dbo.Computadora(UltimoHeartbeat) INCLUDE(NombrePC,EmpleadoId);
GO

IF OBJECT_ID('dbo.Jornada','U') IS NULL
CREATE TABLE dbo.Jornada(
    JornadaId BIGINT IDENTITY(1,1) PRIMARY KEY,
    EmpleadoId INT NOT NULL,
    Inicio DATETIME2 NOT NULL,
    Fin DATETIME2 NULL,
    SegundosActivos INT NOT NULL CONSTRAINT DF_Jornada_Activos DEFAULT(0),
    SegundosInactivos INT NOT NULL CONSTRAINT DF_Jornada_Inactivos DEFAULT(0),
    Estado NVARCHAR(20) NOT NULL CONSTRAINT DF_Jornada_Estado DEFAULT('ABIERTA'),
    CONSTRAINT FK_Jornada_Empleado FOREIGN KEY(EmpleadoId) REFERENCES dbo.Empleado(EmpleadoId),
    CONSTRAINT CK_Jornada_Estado CHECK(Estado IN ('ABIERTA','CERRADA','REVISADA'))
);
GO
CREATE INDEX IX_Jornada_Empleado_Inicio ON dbo.Jornada(EmpleadoId,Inicio DESC);
GO

IF OBJECT_ID('dbo.Actividad','U') IS NULL
CREATE TABLE dbo.Actividad(
    ActividadId BIGINT IDENTITY(1,1) PRIMARY KEY,
    EmpleadoId INT NOT NULL,
    ComputadoraId INT NULL,
    Inicio DATETIME2 NOT NULL,
    Fin DATETIME2 NOT NULL,
    Proceso NVARCHAR(200) NULL,
    Aplicacion NVARCHAR(200) NULL,
    Segundos INT NOT NULL,
    Tipo NVARCHAR(20) NOT NULL CONSTRAINT DF_Actividad_Tipo DEFAULT('SIN_CLASIFICAR'),
    FechaRecepcion DATETIME2 NOT NULL CONSTRAINT DF_Actividad_Recepcion DEFAULT(SYSDATETIME()),
    CONSTRAINT FK_Actividad_Empleado FOREIGN KEY(EmpleadoId) REFERENCES dbo.Empleado(EmpleadoId),
    CONSTRAINT FK_Actividad_PC FOREIGN KEY(ComputadoraId) REFERENCES dbo.Computadora(ComputadoraId),
    CONSTRAINT CK_Actividad_Segundos CHECK(Segundos >= 0),
    CONSTRAINT CK_Actividad_Tipo CHECK(Tipo IN ('PRODUCTIVA','NEUTRA','IMPRODUCTIVA','SIN_CLASIFICAR'))
);
GO
CREATE INDEX IX_Actividad_Empleado_Inicio ON dbo.Actividad(EmpleadoId,Inicio DESC);
GO

IF OBJECT_ID('dbo.SolicitudTiempo','U') IS NULL
CREATE TABLE dbo.SolicitudTiempo(
    SolicitudTiempoId BIGINT IDENTITY(1,1) PRIMARY KEY,
    EmpleadoId INT NOT NULL,
    InicioSolicitado DATETIME2 NOT NULL,
    FinSolicitado DATETIME2 NOT NULL,
    Comentario NVARCHAR(2000) NOT NULL,
    Estado NVARCHAR(20) NOT NULL CONSTRAINT DF_Solicitud_Estado DEFAULT('PENDIENTE'),
    RevisorUsuarioId INT NULL,
    ComentarioRevision NVARCHAR(2000) NULL,
    FechaSolicitud DATETIME2 NOT NULL CONSTRAINT DF_Solicitud_Fecha DEFAULT(SYSDATETIME()),
    FechaRevision DATETIME2 NULL,
    CONSTRAINT FK_Solicitud_Empleado FOREIGN KEY(EmpleadoId) REFERENCES dbo.Empleado(EmpleadoId),
    CONSTRAINT FK_Solicitud_Revisor FOREIGN KEY(RevisorUsuarioId) REFERENCES dbo.Usuario(UsuarioId),
    CONSTRAINT CK_Solicitud_Estado CHECK(Estado IN ('PENDIENTE','APROBADA','RECHAZADA')),
    CONSTRAINT CK_Solicitud_Periodo CHECK(FinSolicitado > InicioSolicitado)
);
GO
CREATE INDEX IX_SolicitudTiempo_Estado ON dbo.SolicitudTiempo(Estado,FechaSolicitud);
GO

IF OBJECT_ID('dbo.Auditoria','U') IS NULL
CREATE TABLE dbo.Auditoria(
    AuditoriaId BIGINT IDENTITY(1,1) PRIMARY KEY,
    UsuarioId INT NULL,
    Accion NVARCHAR(100) NOT NULL,
    Entidad NVARCHAR(100) NOT NULL,
    EntidadId NVARCHAR(100) NULL,
    Detalle NVARCHAR(2000) NULL,
    Fecha DATETIME2 NOT NULL CONSTRAINT DF_Auditoria_Fecha DEFAULT(SYSDATETIME()),
    CONSTRAINT FK_Auditoria_Usuario FOREIGN KEY(UsuarioId) REFERENCES dbo.Usuario(UsuarioId)
);
GO

/* Catálogo inicial de puestos. Gerencias se crean desde el portal. */
IF NOT EXISTS(SELECT 1 FROM dbo.Puesto WHERE Nombre=N'Gerente')
    INSERT dbo.Puesto(Nombre) VALUES(N'Gerente');
IF NOT EXISTS(SELECT 1 FROM dbo.Puesto WHERE Nombre=N'Jefe')
    INSERT dbo.Puesto(Nombre) VALUES(N'Jefe');
IF NOT EXISTS(SELECT 1 FROM dbo.Puesto WHERE Nombre=N'Analista')
    INSERT dbo.Puesto(Nombre) VALUES(N'Analista');
IF NOT EXISTS(SELECT 1 FROM dbo.Puesto WHERE Nombre=N'Asistente')
    INSERT dbo.Puesto(Nombre) VALUES(N'Asistente');
GO
