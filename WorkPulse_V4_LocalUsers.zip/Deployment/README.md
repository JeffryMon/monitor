# Despliegue recomendado

1. Publicar la API detrás de HTTPS.
2. Crear la base con `Database/WorkPulse_V4.sql`.
3. Crear el primer usuario administrador mediante un proceso de bootstrap seguro (no usar clave por defecto en producción).
4. Crear gerencias y puestos.
5. Crear usuarios con rol y jefe directo.
6. Generar código de vinculación de un solo uso para cada PC.
7. Instalar el agente en el equipo y usar el código para vincularlo al empleado.
8. Distribuir instalador firmado por GPO o Intune; configurar recuperación del servicio.
9. Probar reinicio, pérdida de red, cambio de usuario y revocación de dispositivo.

El nombre de sesión Windows solo es metadato del equipo; no autentica al usuario de WorkPulse ni sustituye la selección/vinculación del empleado.
