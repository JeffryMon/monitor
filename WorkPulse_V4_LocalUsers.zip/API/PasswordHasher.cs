using System;
using System.Security.Cryptography;

namespace WorkPulse.Api.Security
{
    public static class PasswordHasher
    {
        private const int SaltSize = 16;
        private const int KeySize = 32;
        private const int Iterations = 210000;

        public static string Hash(string password)
        {
            if (String.IsNullOrWhiteSpace(password)) throw new ArgumentException("La contraseña es obligatoria.");
            byte[] salt = new byte[SaltSize];
            using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(salt);
            using (var pbkdf2 = new Rfc2898DeriveBytes(password, salt, Iterations, HashAlgorithmName.SHA256))
            {
                byte[] key = pbkdf2.GetBytes(KeySize);
                return "PBKDF2-SHA256$" + Iterations + "$" +
                    Convert.ToBase64String(salt) + "$" + Convert.ToBase64String(key);
            }
        }

        public static bool Verify(string password, string stored)
        {
            if (String.IsNullOrEmpty(password) || String.IsNullOrEmpty(stored)) return false;
            var parts = stored.Split('$');
            if (parts.Length != 4 || parts[0] != "PBKDF2-SHA256") return false;
            int iterations;
            if (!Int32.TryParse(parts[1], out iterations) || iterations < 100000) return false;
            byte[] salt, expected;
            try { salt = Convert.FromBase64String(parts[2]); expected = Convert.FromBase64String(parts[3]); }
            catch { return false; }
            using (var pbkdf2 = new Rfc2898DeriveBytes(password, salt, iterations, HashAlgorithmName.SHA256))
            {
                byte[] actual = pbkdf2.GetBytes(expected.Length);
                int diff = actual.Length ^ expected.Length;
                for (int i = 0; i < Math.Min(actual.Length, expected.Length); i++) diff |= actual[i] ^ expected[i];
                return diff == 0;
            }
        }
    }
}
