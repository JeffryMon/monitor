using System;

namespace WorkPulse.Api.Contracts
{
    public sealed class CreateUserRequest
    {
        public string NombreUsuario { get; set; }
        public string Password { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Correo { get; set; }
        public string Telefono { get; set; }
        public string Rol { get; set; } // ADMIN, GERENCIA, JEFE, EMPLEADO
        public int? GerenciaId { get; set; }
        public int? PuestoId { get; set; }
        public int? JefeUsuarioId { get; set; }
        public string CodigoEmpleado { get; set; }
        public DateTime? FechaIngreso { get; set; }
    }

    public sealed class LoginRequest
    {
        public string NombreUsuario { get; set; }
        public string Password { get; set; }
    }

    public sealed class EmployeeSummary
    {
        public int UsuarioId { get; set; }
        public int EmpleadoId { get; set; }
        public string NombreUsuario { get; set; }
        public string NombreCompleto { get; set; }
        public string Correo { get; set; }
        public string Rol { get; set; }
        public string Gerencia { get; set; }
        public string Puesto { get; set; }
        public string Jefe { get; set; }
        public string EstadoLaboral { get; set; }
    }
}
