using System;
using System.Data;
using System.Data.SqlClient;
using WorkPulse.Api.Contracts;
using WorkPulse.Api.Security;

namespace WorkPulse.Api.Services
{
    // Ejemplo de servicio ADO.NET. La cadena de conexión debe venir de Web.config en el servidor.
    public sealed class UserService
    {
        private readonly string _connectionString;
        public UserService(string connectionString) { _connectionString = connectionString; }

        public int CreateUser(CreateUserRequest r, int? actorUserId)
        {
            if (r == null) throw new ArgumentNullException(nameof(r));
            if (String.IsNullOrWhiteSpace(r.NombreUsuario) || String.IsNullOrWhiteSpace(r.Password) ||
                String.IsNullOrWhiteSpace(r.Nombre) || String.IsNullOrWhiteSpace(r.Apellido))
                throw new ArgumentException("Usuario, contraseña, nombre y apellido son obligatorios.");
            if (r.Password.Length < 10) throw new ArgumentException("La contraseña debe tener al menos 10 caracteres.");
            string[] roles = { "ADMIN", "GERENCIA", "JEFE", "EMPLEADO" };
            if (Array.IndexOf(roles, (r.Rol ?? "").ToUpperInvariant()) < 0)
                throw new ArgumentException("Rol no válido.");

            using (var cn = new SqlConnection(_connectionString))
            using (var cmd = cn.CreateCommand())
            {
                cn.Open();
                using (var tx = cn.BeginTransaction())
                {
                    cmd.Transaction = tx;
                    cmd.CommandText = @"
INSERT dbo.Usuario(NombreUsuario,PasswordHash,Nombre,Apellido,Correo,Telefono,Rol,CreadoPor,DebeCambiarClave)
VALUES(@u,@p,@n,@a,@c,@t,@r,@actor,1);
SELECT CAST(SCOPE_IDENTITY() AS INT);";
                    cmd.Parameters.Add("@u", SqlDbType.NVarChar, 80).Value = r.NombreUsuario.Trim();
                    cmd.Parameters.Add("@p", SqlDbType.NVarChar, 500).Value = PasswordHasher.Hash(r.Password);
                    cmd.Parameters.Add("@n", SqlDbType.NVarChar, 100).Value = r.Nombre.Trim();
                    cmd.Parameters.Add("@a", SqlDbType.NVarChar, 100).Value = r.Apellido.Trim();
                    cmd.Parameters.Add("@c", SqlDbType.NVarChar, 254).Value = (object)r.Correo ?? DBNull.Value;
                    cmd.Parameters.Add("@t", SqlDbType.NVarChar, 40).Value = (object)r.Telefono ?? DBNull.Value;
                    cmd.Parameters.Add("@r", SqlDbType.NVarChar, 20).Value = r.Rol.ToUpperInvariant();
                    cmd.Parameters.Add("@actor", SqlDbType.Int).Value = (object)actorUserId ?? DBNull.Value;
                    int userId = (int)cmd.ExecuteScalar();

                    cmd.Parameters.Clear();
                    cmd.CommandText = @"
INSERT dbo.Empleado(UsuarioId,CodigoEmpleado,GerenciaId,PuestoId,JefeUsuarioId,FechaIngreso)
VALUES(@id,@codigo,@gerencia,@puesto,@jefe,@ingreso);";
                    cmd.Parameters.Add("@id", SqlDbType.Int).Value = userId;
                    cmd.Parameters.Add("@codigo", SqlDbType.NVarChar, 40).Value = (object)r.CodigoEmpleado ?? DBNull.Value;
                    cmd.Parameters.Add("@gerencia", SqlDbType.Int).Value = (object)r.GerenciaId ?? DBNull.Value;
                    cmd.Parameters.Add("@puesto", SqlDbType.Int).Value = (object)r.PuestoId ?? DBNull.Value;
                    cmd.Parameters.Add("@jefe", SqlDbType.Int).Value = (object)r.JefeUsuarioId ?? DBNull.Value;
                    cmd.Parameters.Add("@ingreso", SqlDbType.Date).Value = (object)r.FechaIngreso ?? DBNull.Value;
                    cmd.ExecuteNonQuery();
                    tx.Commit();
                    return userId;
                }
            }
        }

        public bool VerifyLogin(string username, string password, out int userId, out string role)
        {
            userId = 0; role = null;
            using (var cn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(
                "SELECT UsuarioId,PasswordHash,Rol FROM dbo.Usuario WHERE NombreUsuario=@u AND Estado=1", cn))
            {
                cmd.Parameters.Add("@u", SqlDbType.NVarChar, 80).Value = username ?? "";
                cn.Open();
                using (var rd = cmd.ExecuteReader(CommandBehavior.SingleRow))
                {
                    if (!rd.Read()) return false;
                    int id = rd.GetInt32(0);
                    string hash = rd.GetString(1);
                    string r = rd.GetString(2);
                    if (!PasswordHasher.Verify(password, hash)) return false;
                    userId = id; role = r; return true;
                }
            }
        }
    }
}
