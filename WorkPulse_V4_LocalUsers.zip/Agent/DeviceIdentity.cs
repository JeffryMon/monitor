using System;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;

namespace WorkPulse.Agent
{
    // Identidad del equipo. No consulta Active Directory ni presupone que Windows user = empleado.
    public sealed class DeviceIdentity
    {
        public string NombrePC { get; private set; }
        public string UsuarioWindowsSesion { get; private set; }
        public string SistemaOperativo { get; private set; }
        public string DireccionIP { get; private set; }

        public static DeviceIdentity Read()
        {
            string ip = NetworkInterface.GetAllNetworkInterfaces()
                .Where(n => n.OperationalStatus == OperationalStatus.Up)
                .SelectMany(n => n.GetIPProperties().UnicastAddresses)
                .Where(a => a.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork &&
                            !IPAddress.IsLoopback(a.Address))
                .Select(a => a.Address.ToString()).FirstOrDefault();
            return new DeviceIdentity
            {
                NombrePC = Environment.MachineName,
                UsuarioWindowsSesion = Environment.UserDomainName + "\\" + Environment.UserName,
                SistemaOperativo = Environment.OSVersion.VersionString,
                DireccionIP = ip
            };
        }
    }
}
