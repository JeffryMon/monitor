# WorkPulse V4 — usuarios locales y estructura organizacional

Esta versión cambia la identidad de empleados: **ya no usa Active Directory para autenticar empleados**.
Los usuarios se crean y administran dentro de WorkPulse. El agente puede seguir reportando el nombre de la PC,
pero la vinculación empleado-PC se realiza mediante un código de vinculación generado desde el portal.

## Estructura

- `Database/WorkPulse_V4.sql`: esquema SQL Server para usuarios, empleados, gerencias, puestos, jerarquía, PCs,
  jornadas, actividad, solicitudes de tiempo manual, aprobaciones y auditoría.
- `API/Contracts.cs`: contratos de datos para la API.
- `API/PasswordHasher.cs`: hashing de contraseñas con PBKDF2.
- `API/UserService.cs`: ejemplo de creación de usuarios y verificación de contraseñas.
- `Agent/DeviceIdentity.cs`: identidad del equipo sin consultar AD.
- `Agent/agent.config.example.json`: configuración del agente.
- `Portal/usuarios.html`: prototipo funcional del módulo de empleados/usuarios y jerarquía (datos de demostración locales).
- `Deployment/README.md`: notas de despliegue.

## Roles

- `ADMIN`: administra usuarios, catálogos, estructura y configuración.
- `GERENCIA`: consulta su gerencia y equipos subordinados.
- `JEFE`: administra su equipo y revisa solicitudes de tiempo.
- `EMPLEADO`: consulta su jornada y solicita reconocimiento de tiempo.

## Datos de empleado

Se incluyen nombres, apellidos, nombre de usuario, correo, teléfono, código de empleado, puesto,
gerencia, jefe directo, fecha de ingreso, horario de referencia, estado, zona horaria y notas administrativas.

## Seguridad y despliegue

Este paquete es una base de implementación y prototipo; no es un instalador compilado ni un sistema validado para producción.
Antes de producción:
1. Configura la cadena de conexión en el servidor, no en el cliente.
2. Publica la API solo por HTTPS.
3. Implementa autorización por rol en cada endpoint y valida la gerencia/equipo en servidor.
4. Configura política de contraseñas, bloqueo por intentos, caducidad de sesión y auditoría.
5. No despliegues el usuario inicial `admin`/`admin` en producción. Crea un administrador temporal y fuerza cambio de clave.
6. Para agente-PC, genera un código de emparejamiento de un solo uso y registra el dispositivo en el servidor.
7. Compila y prueba en un entorno de pruebas antes de distribuir mediante GPO/instalador.

El prototipo HTML no persiste a SQL Server; sirve para revisar el flujo visual. La API requiere integración y pruebas en tu entorno.
