# SQL Server Manager V4

Consola centralizada para monitorizar y administrar múltiples SQL Server mediante **Windows Authentication**.

## V4 incluye
- Dashboard ejecutivo con KPIs y estado ONLINE/OFFLINE.
- Búsqueda de servidores y selección de servidor por módulo.
- Inventario ampliado: PROD/QA/DEV/UAT/DR/TEST, versión, edición, SO, ubicación, responsable, tags y descripción.
- Logins: búsqueda, estado ACTIVE/DISABLED y botones para habilitar/deshabilitar.
- Bases de datos: búsqueda y estado ONLINE/OFFLINE con colores.
- Sesiones y KILL SPID.
- Métricas: CPU, memoria, usuarios conectados, bases online/offline, bloqueos y espacio libre.
- Gráficos doughnut de CPU, memoria y bases; histórico de CPU/conexiones.
- Auditorías reales configuradas en cada SQL Server, con consulta de eventos por auditoría, mes y año mediante `sys.fn_get_audit_file`.
- Alertas por CPU, memoria, conexiones, BD offline, bloqueos, cantidad de BD y espacio libre. Las capturas de métricas generan incidencias abiertas y permiten cerrarlas con comentario.
- Timeline por servidor para mantenimientos, cambios, incidentes, upgrades, backups y comentarios.
- Entradas de datos en modales.
- Windows Authentication; no se guardan contraseñas SQL.

## Requisitos
- .NET 8 SDK
- SQL Server para `SQL_ADMIN_CENTER`
- Cuenta Windows que ejecute la aplicación con permisos en los SQL Server administrados.

## Instalación
1. Ejecutar `database/01_create_database.sql` en el SQL Server central.
2. Revisar `src/SQLServerManager.Api/appsettings.json`.
3. Ejecutar `dotnet restore` y `dotnet run`.
4. Abrir Swagger o la interfaz web.

## Permisos importantes
Para deshabilitar/habilitar logins se requiere el permiso SQL Server correspondiente, por ejemplo `ALTER ANY LOGIN` o un permiso equivalente.
Para consultar auditorías de archivo, la cuenta Windows necesita los permisos necesarios sobre los archivos de auditoría y las vistas/funciones del servidor.


## V5.1
- Corregido Models.cs: propiedad JobDto.LastRun.
- Nueva sección Archivos por servidor.
- Almacenamiento central de documentación con categoría, descripción, descarga y eliminación.
- Límite de 50 MB por archivo.
