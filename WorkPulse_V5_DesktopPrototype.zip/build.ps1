$ErrorActionPreference = "Stop"
$project = Join-Path $PSScriptRoot "src\WorkPulse.Agent\WorkPulse.Agent.csproj"
$dist = Join-Path $PSScriptRoot "dist"
New-Item -ItemType Directory -Force -Path $dist | Out-Null
$msbuild = Get-Command msbuild.exe -ErrorAction SilentlyContinue
if (-not $msbuild) {
  $candidates = @(
    "$env:ProgramFiles\Microsoft Visual Studio\2022\Community\MSBuild\Current\Bin\MSBuild.exe",
    "$env:ProgramFiles\Microsoft Visual Studio\2022\BuildTools\MSBuild\Current\Bin\MSBuild.exe",
    "$env:ProgramFiles(x86)\Microsoft Visual Studio\2019\BuildTools\MSBuild\Current\Bin\MSBuild.exe"
  )
  $msbuildPath = $candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
} else { $msbuildPath = $msbuild.Source }
if (-not $msbuildPath) {
  throw "No encuentro MSBuild. Instala Visual Studio/Build Tools con .NET desktop development o abre src\WorkPulse.sln en Visual Studio."
}
& $msbuildPath $project /t:Rebuild /p:Configuration=Release /p:OutputPath="$dist\" /verbosity:minimal
if ($LASTEXITCODE -ne 0) { throw "La compilación falló con código $LASTEXITCODE" }
Write-Host "Compilación lista: $dist\WorkPulse.Agent.exe" -ForegroundColor Green
