using System;
using System.Drawing;
using System.Net.NetworkInformation;
using System.Windows.Forms;

namespace WorkPulse.Agent
{
    public sealed class MainForm : Form
    {
        private readonly Label _status = new Label();
        private readonly Label _pc = new Label();
        private readonly Label _user = new Label();
        private readonly Label _ip = new Label();
        private readonly Label _os = new Label();
        private readonly Label _time = new Label();

        public MainForm()
        {
            Text = "WorkPulse Agent";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(560, 390);
            MinimumSize = new Size(500, 350);
            Font = new Font("Segoe UI", 10);
            BackColor = Color.FromArgb(246, 248, 252);
            var title = new Label { Text = "WorkPulse", Font = new Font("Segoe UI", 20, FontStyle.Bold), ForeColor = Color.FromArgb(29, 47, 76), AutoSize = true, Location = new Point(24, 20) };
            var subtitle = new Label { Text = "Agente de escritorio · estado visible", ForeColor = Color.DimGray, AutoSize = true, Location = new Point(27, 58) };
            _status.Location = new Point(28, 100); _status.AutoSize = true; _status.Font = new Font("Segoe UI", 11, FontStyle.Bold); _status.ForeColor = Color.SeaGreen;
            var panel = new Panel { Location = new Point(24, 132), Size = new Size(490, 165), BackColor = Color.White, Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right };
            AddDetail(panel, "Computadora", _pc, 18, 16);
            AddDetail(panel, "Sesión Windows", _user, 18, 52);
            AddDetail(panel, "Dirección IP", _ip, 18, 88);
            AddDetail(panel, "Sistema", _os, 18, 124);
            _time.Location = new Point(28, 312); _time.AutoSize = true; _time.ForeColor = Color.DimGray;
            Controls.Add(title); Controls.Add(subtitle); Controls.Add(_status); Controls.Add(panel); Controls.Add(_time);
            RefreshDetails();
        }

        private void AddDetail(Control parent, string caption, Label value, int x, int y)
        {
            var label = new Label { Text = caption + ":", Location = new Point(x, y), AutoSize = true, ForeColor = Color.Gray };
            value.Location = new Point(x + 135, y); value.AutoSize = true; value.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            parent.Controls.Add(label); parent.Controls.Add(value);
        }

        public void RefreshDetails()
        {
            _status.Text = "● Agente activo (modo demostración)";
            _pc.Text = Environment.MachineName;
            _user.Text = Environment.UserDomainName + "\\" + Environment.UserName;
            _ip.Text = GetIP();
            _os.Text = Environment.OSVersion.VersionString;
            _time.Text = "Última actualización local: " + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
        }

        private string GetIP()
        {
            try
            {
                foreach (var a in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (a.OperationalStatus != OperationalStatus.Up) continue;
                    foreach (var u in a.GetIPProperties().UnicastAddresses)
                        if (u.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork && !System.Net.IPAddress.IsLoopback(u.Address))
                            return u.Address.ToString();
                }
            }
            catch { }
            return "No disponible";
        }
    }
}
