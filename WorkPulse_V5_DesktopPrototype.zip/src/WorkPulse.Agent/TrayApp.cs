using System;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Win32;
using System.IO;

namespace WorkPulse.Agent
{
    public sealed class TrayApp : ApplicationContext
    {
        private readonly NotifyIcon _tray;
        private readonly Timer _timer;
        private readonly MainForm _form;
        private readonly ToolStripMenuItem _status;
        private readonly ToolStripMenuItem _startup;

        public TrayApp()
        {
            _form = new MainForm();
            var menu = new ContextMenuStrip();
            menu.Items.Add("Abrir WorkPulse", null, (s, e) => ShowForm());
            _status = new ToolStripMenuItem("Estado: activo (prototipo)") { Enabled = false };
            menu.Items.Add(_status);
            _startup = new ToolStripMenuItem("Iniciar con Windows") { CheckOnClick = true, Checked = IsStartupEnabled() };
            _startup.Click += (s, e) => SetStartup(_startup.Checked);
            menu.Items.Add(_startup);
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("Salir", null, (s, e) => ExitApp());

            _tray = new NotifyIcon
            {
                Text = "WorkPulse — agente visible",
                Icon = SystemIcons.Application,
                ContextMenuStrip = menu,
                Visible = true
            };
            _tray.DoubleClick += (s, e) => ShowForm();
            _tray.BalloonTipTitle = "WorkPulse";
            _tray.BalloonTipText = "El agente está activo en esta sesión.";
            _tray.BalloonTipIcon = ToolTipIcon.Info;
            _tray.ShowBalloonTip(1800);

            _timer = new Timer { Interval = 30000 };
            _timer.Tick += (s, e) => RefreshStatus();
            _timer.Start();
        }

        private void ShowForm()
        {
            if (_form.IsDisposed) return;
            _form.RefreshDetails();
            _form.Show();
            _form.WindowState = FormWindowState.Normal;
            _form.Activate();
        }

        private void RefreshStatus()
        {
            _status.Text = "Estado: activo (prototipo) · " + DateTime.Now.ToString("HH:mm:ss");
            _tray.Text = "WorkPulse — activo · " + Environment.MachineName;
            if (!_form.IsDisposed) _form.RefreshDetails();
        }

        private string StartupPath
        {
            get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Startup), "WorkPulse.lnk"); }
        }

        private bool IsStartupEnabled() { return File.Exists(StartupPath); }

        private void SetStartup(bool enabled)
        {
            try
            {
                if (enabled)
                {
                    string exe = Application.ExecutablePath;
                    string script = "$s=(New-Object -COM WScript.Shell).CreateShortcut('" + StartupPath.Replace("'", "''") + "');$s.TargetPath='" + exe.Replace("'", "''") + "';$s.WorkingDirectory='" + Path.GetDirectoryName(exe).Replace("'", "''") + "';$s.Save()";
                    var psi = new System.Diagnostics.ProcessStartInfo("powershell.exe", "-NoProfile -ExecutionPolicy Bypass -Command \"" + script.Replace("\"", "\\\"") + "\"");
                    psi.CreateNoWindow = true; psi.UseShellExecute = false;
                    using (var p = System.Diagnostics.Process.Start(psi)) p.WaitForExit(5000);
                }
                else if (File.Exists(StartupPath)) File.Delete(StartupPath);
                _startup.Checked = IsStartupEnabled();
                MessageBox.Show(_startup.Checked ? "WorkPulse iniciará al iniciar sesión en Windows." : "Se quitó el inicio automático.", "WorkPulse", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo cambiar el inicio automático: " + ex.Message, "WorkPulse", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                _startup.Checked = IsStartupEnabled();
            }
        }

        private void ExitApp()
        {
            _timer.Stop();
            _tray.Visible = false;
            _tray.Dispose();
            _form.Close();
            _form.Dispose();
            ExitThread();
        }

        protected override void ExitThreadCore()
        {
            if (_tray != null) _tray.Visible = false;
            base.ExitThreadCore();
        }
    }
}
