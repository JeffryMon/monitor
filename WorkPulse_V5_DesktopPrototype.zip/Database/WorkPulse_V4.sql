-- Sustituye este archivo por el script Database/WorkPulse_V4.sql de la entrega V4 si ya lo tienes.
-- Esta V5 se centra en probar el agente visible de Windows.
CREATE TABLE dbo.WorkPulsePrototypeInfo(
 Id INT IDENTITY(1,1) PRIMARY KEY,
 Version NVARCHAR(20) NOT NULL,
 CreatedAt DATETIME2 NOT NULL DEFAULT(SYSDATETIME())
);
INSERT dbo.WorkPulsePrototypeInfo(Version) VALUES('V5-DesktopPrototype');
