# WorkPulse V5 — prototipo ejecutable (Windows)

Esta entrega prioriza que puedas **probar un ejecutable visible en la bandeja de Windows**.
Incluye:
- Aplicación WinForms .NET Framework 4.7.2 con icono de bandeja.
- Estado visible: conectado/desconectado (demo local), nombre de PC, usuario Windows y hora.
- Menú de bandeja: Abrir WorkPulse, Estado, Iniciar con Windows, Salir.
- Publicación con `build.ps1` si tienes Visual Studio Build Tools o MSBuild instalado.
- Portal de demostración HTML.
- Esquema SQL V4 incluido como base.

## Limitación importante
Este prototipo no se conecta todavía a una API/SQL Server ni envía datos de empleados reales. La bandeja y el estado son funcionales localmente para probar el ejecutable y el comportamiento visible. No se presenta como un agente de monitorización ya desplegable.

## Requisitos
- Windows 10/11.
- .NET Framework 4.7.2 Developer Pack.
- Visual Studio 2019/2022 con workload .NET desktop development, o Build Tools con MSBuild.
- PowerShell.

## Compilar
Abre PowerShell en esta carpeta y ejecuta:
```powershell
.\build.ps1
```
Si `msbuild.exe` está disponible, compilará `src\WorkPulse.Agent\WorkPulse.Agent.csproj` y dejará el ejecutable en `dist\WorkPulse.Agent.exe`.

Alternativamente abre `src\WorkPulse.sln` en Visual Studio, restaura si solicita y compila en Release.

## Probar
Ejecuta `dist\WorkPulse.Agent.exe`. Aparecerá un icono en el área de notificación (bandeja) junto al reloj. Si Windows lo oculta en el menú de iconos adicionales, abre la flecha `^` para verlo. Desde Configuración > Personalización > Barra de tareas > Otros iconos de la bandeja, activa WorkPulse para mostrarlo siempre.

## Inicio automático
En el menú del icono selecciona `Iniciar con Windows`. Esto crea/quita un acceso directo en la carpeta Inicio del usuario actual. Es visible y fácil de desactivar; para despliegue corporativo se sustituirá por instalador firmado y política TI.

## Seguridad y alcance
El prototipo no captura pulsaciones, contraseñas, pantallas ni contenido de documentos. Muestra claramente que está activo. No incluye persistencia oculta ni evita que un administrador lo cierre.
