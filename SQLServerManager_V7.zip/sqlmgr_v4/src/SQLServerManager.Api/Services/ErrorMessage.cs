using Microsoft.Data.SqlClient;

namespace SQLServerManager.Api.Services;

public static class ErrorMessage
{
    public static string From(Exception ex) => ex switch
    {
        SqlException => "No se pudo conectar o consultar el SQL Server. Verifique la conexión y los permisos de Windows.",
        TimeoutException => "El servidor no respondió a tiempo.",
        UnauthorizedAccessException => "La cuenta de Windows no tiene permisos para realizar esta operación.",
        ArgumentException a => string.IsNullOrWhiteSpace(a.Message) ? "Los datos enviados no son válidos." : a.Message,
        _ => "No se pudo completar la operación."
    };
}
