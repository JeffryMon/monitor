using System.Security.Claims;
using System.Security.Cryptography;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using SQLServerManager.Api.Models;

namespace SQLServerManager.Api.Services;

public class AuthService
{
    readonly CentralRepository repo;
    public AuthService(CentralRepository repo) => this.repo = repo;

    // El usuario se administra directamente en SQL_ADMIN_CENTER.
    // Esta aplicación solo valida las credenciales; no crea usuarios ni roles.
    public async Task<AppUserDto?> ValidateAsync(string username, string password)
    {
        var user = await repo.GetAppUserAsync(username);
        if (user is null || !user.IsActive || !Verify(password, user.PasswordHash)) return null;
        return user;
    }

    public async Task SignInAsync(HttpContext http, AppUserDto user)
    {
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.UserId.ToString()),
            new(ClaimTypes.Name, user.Username)
        };
        var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
        await http.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));
    }

    public static string Hash(string password)
    {
        var salt = RandomNumberGenerator.GetBytes(16);
        var hash = Rfc2898DeriveBytes.Pbkdf2(password, salt, 120000, HashAlgorithmName.SHA256, 32);
        return $"PBKDF2-SHA256$120000${Convert.ToBase64String(salt)}${Convert.ToBase64String(hash)}";
    }

    public static bool Verify(string password, string encoded)
    {
        try
        {
            var p = encoded.Split('$');
            if (p.Length != 4 || p[0] != "PBKDF2-SHA256") return false;
            var salt = Convert.FromBase64String(p[2]);
            var expected = Convert.FromBase64String(p[3]);
            var actual = Rfc2898DeriveBytes.Pbkdf2(password, salt, int.Parse(p[1]), HashAlgorithmName.SHA256, expected.Length);
            return CryptographicOperations.FixedTimeEquals(actual, expected);
        }
        catch { return false; }
    }
}
