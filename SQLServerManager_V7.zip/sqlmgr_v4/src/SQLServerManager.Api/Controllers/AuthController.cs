using System.Security.Principal;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SQLServerManager.Api.Models;
using SQLServerManager.Api.Services;

namespace SQLServerManager.Api.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    readonly AuthService auth;
    public AuthController(AuthService auth) => this.auth = auth;

    [AllowAnonymous, HttpPost("login")]
    public async Task<IActionResult> Login(LoginRequest x)
    {
        if (string.IsNullOrWhiteSpace(x.Username) || string.IsNullOrWhiteSpace(x.Password))
            return BadRequest(new { error = "Ingrese usuario y contraseña." });

        try
        {
            var user = await auth.ValidateAsync(x.Username.Trim(), x.Password);
            if (user is null) return Unauthorized(new { error = "Usuario o contraseña incorrectos." });
            await auth.SignInAsync(HttpContext, user);
            return Ok(new { username = user.Username });
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { error = ErrorMessage.From(ex) });
        }
    }

    [Authorize, HttpPost("logout")]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return Ok();
    }

    [AllowAnonymous, HttpGet("me")]
    public IActionResult Me() => Ok(new
    {
        authenticated = User.Identity?.IsAuthenticated == true,
        username = User.Identity?.Name
    });

    [Authorize, HttpGet("windows-identity")]
    public IActionResult WindowsIdentityInfo()
    {
        var identity = WindowsIdentity.GetCurrent();
        return Ok(new
        {
            windowsUser = identity?.Name ?? Environment.UserName,
            note = "Esta es la identidad de Windows que utiliza Integrated Security para las conexiones desde IIS."
        });
    }
}
