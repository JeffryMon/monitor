using Microsoft.AspNetCore.Mvc; using Microsoft.AspNetCore.Authorization; using SQLServerManager.Api.Models; using SQLServerManager.Api.Services;
namespace SQLServerManager.Api.Controllers;
[ApiController][Route("api/v2")][Authorize]
public class V2Controller:ControllerBase{readonly CentralRepository r;readonly SqlServerService s;public V2Controller(CentralRepository r,SqlServerService s){this.r=r;this.s=s;}
[HttpPost("servers/{id:int}/metrics/collect")] public async Task<IActionResult> Collect(int id){var v=await r.Server(id);if(v is null)return NotFound();try{var m=await s.Dashboard(v);await r.SaveMetric(id,m);await r.EvaluateAlerts(id,m);return Ok(m);}catch(Exception e){return BadRequest(new{error=ErrorMessage.From(e)});}}
[HttpGet("servers/{id:int}/metrics")] public async Task<IActionResult> Metrics(int id,[FromQuery]int hours=24)=>Ok(await r.Metrics(id,Math.Clamp(hours,1,720)));
[HttpGet("audit")] public async Task<IActionResult> Audit([FromQuery]int take=300)=>Ok(await r.Audit(Math.Clamp(take,1,1000)));
[HttpGet("alerts")] public async Task<IActionResult> Alerts()=>Ok(await r.Alerts());
[HttpPost("alerts")][Authorize] public async Task<IActionResult> Alert(CreateAlertRuleRequest x)=>Ok(new{id=await r.AddAlert(x)});
[HttpGet("alert-events")] public async Task<IActionResult> AlertEvents([FromQuery]int? serverId,[FromQuery]bool openOnly=false)=>Ok(await r.AlertEvents(serverId,openOnly));
[HttpPost("alert-events/{id:long}/close")][Authorize] public async Task<IActionResult> CloseAlert(long id,AlertCloseRequest x){await r.CloseAlert(id,x.Comment,User?.Identity?.Name);return Ok();}
[HttpDelete("alerts/{id:int}")][Authorize] public async Task<IActionResult> DeleteAlert(int id){await r.DeleteAlert(id);return Ok();}
[HttpGet("servers/{id:int}/timeline")] public async Task<IActionResult> Timeline(int id)=>Ok(await r.Timeline(id));
[HttpPost("servers/{id:int}/timeline")][Authorize] public async Task<IActionResult> AddTimeline(int id,TimelineCreateRequest x){await r.AddTimeline(id,x,User?.Identity?.Name);return Ok();}
}
