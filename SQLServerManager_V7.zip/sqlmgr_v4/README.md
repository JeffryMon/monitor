# SQL Server Manager V7

Consola web para monitorizar y administrar múltiples SQL Server.

## Autenticación de la aplicación

El inicio de sesión solamente valida usuario, contraseña y estado desde `SQL_ADMIN_CENTER.dbo.APP_USER`. La aplicación **no crea, edita, activa/desactiva ni administra usuarios o roles** desde la interfaz.

Los usuarios se administran directamente en la base de datos central. Las contraseñas se almacenan como PBKDF2-SHA256.

## Conexiones a SQL Server

Todas las conexiones a los servidores registrados usan:

`Integrated Security=True`

No se almacenan credenciales SQL. En IIS, SQL Server recibe la identidad Windows del proceso que ejecuta el Application Pool. El botón de prueba de conexión muestra la cuenta Windows usada y comprueba realmente si esa cuenta puede conectarse al servidor.

Para IIS se recomienda una cuenta de servicio de dominio, por ejemplo `DOMINIO\\svc_sqlmanager`, asignada al Application Pool.

## Errores

Los errores técnicos no se muestran directamente al usuario. La API devuelve mensajes simples, por ejemplo:

- `No se pudo conectar o consultar el SQL Server. Verifique la conexión y los permisos de Windows.`
- `La cuenta de Windows no tiene permisos para realizar esta operación.`
- `El servidor no respondió a tiempo.`

## V7

- Login solamente contra usuarios existentes en la BD central.
- Sin administración de usuarios/roles en la UI.
- Windows Authentication para SQL Server.
- Identidad Windows efectiva visible en prueba de conexión.
- Manejo de excepciones sencillo.
